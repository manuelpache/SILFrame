#ifndef REMOVEHELPER_H
#define REMOVEHELPER_H
#include <QString>
#include <QObject>


class RemoveHelper
{
public:
    RemoveHelper();
    bool remove(QString);
    bool listRemove(QString);
    bool removeIniAndSo(QString);
};

#endif // REMOVEHELPER_H
