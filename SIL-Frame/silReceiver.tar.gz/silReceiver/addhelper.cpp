#include "addhelper.h"
#include <QString>
#include <QStringList>
#include <QFile>
#include <QDir>
#include <QTextStream>
#include <QDebug>
#include <QFileInfoList>

/**
 * @brief AddHelper::AddHelper
 */
AddHelper::AddHelper()
{

}

/**
 * @brief Adds the plugin into the plugin_list
 * @param plugin
 * @return
 */
bool AddHelper::listRenew(QString plugin){
    QFile list(QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "SIL" + QDir::separator() + "plugin_list");
    if(list.exists()){
        if(!list.open(QIODevice::ReadWrite | QIODevice::Text)) {
            qWarning() << "Could not open plugin_list";
            return false;
        }
        QTextStream in(&list);
        QStringList fields;
        while(!in.atEnd()){
            QString line = in.readLine();
            fields.append(line);
        }
        list.resize(0);
        fields.append(plugin);
        fields.removeDuplicates();
        for(int j = 0; j < fields.length(); j++){
            in << fields.at(j) << "\n";
        }
        list.close();
    }
    else {
        int mkmydir = system("cd && touch ~/sil/SIL/plugin_list");
        if (list.open(QFile::WriteOnly | QFile::Append) && mkmydir == 0)
        {
            QTextStream stream(&list);
            stream << plugin << "\n";
            list.close();

        } else {
            qWarning() << list.errorString();
            return false;
        }
    }
    return true;
}

/**
 * @brief Removes the config.ini and the pro-file into an own directory
 * @param plugin
 * @return
 */
bool AddHelper::configDir(QString plugin){
    QFile file(QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "build" + QDir::separator() + "config_" + plugin + "ini");
    QString build = QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "build";
    QString mainDir = QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "SIL" + QDir::separator() + plugin;
    if(!file.exists()){
        QFileInfoList fileList = QDir(mainDir).entryInfoList(QDir::NoDotAndDotDot|QDir::AllEntries);
        for(int i = 0; i < fileList.size(); i++){
            if(fileList.at(i).completeSuffix() == "ini"){
                QString iniFile = fileList.at(i).filePath();
                QString iniName = fileList.at(i).fileName();
                QFile().copy(iniFile, build + QDir::separator() + iniName);
            }
        }
    }
    return true;
}

/**
 * @brief AddHelper::copyhandle
 * @param plugin
 * @return
 */
bool AddHelper::copyhandle(QString plugin){
    bool found;
    QString build = QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "build";
    QString mainDir = QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "SIL" + QDir::separator() + plugin;
    QFileInfoList fileList = QDir(mainDir).entryInfoList(QDir::NoDotAndDotDot|QDir::AllEntries);
    for(int i = 0; i < fileList.length(); i++){
        if(fileList.at(i).completeSuffix() == "pro"){
            QString proFilestd = fileList.at(i).filePath();
            QFile proFile(proFilestd);
            proFile.open(QIODevice::ReadWrite);
            QTextStream in (&proFile);
            while(!in.atEnd()){
                QString content = in.readLine();
                if(content.contains("TARGET = ../../build/")){
                    QString fileBase = content.remove("TARGET = ../../build/");
                    QString soName = "lib" + fileBase + ".so";
                    found = QFile().copy(build + QDir::separator() + soName, mainDir + QDir::separator() + soName);
                }
            }
            proFile.close();
        }
    }
    return found;
}

/**
 * @brief AddHelper::copybackhandle
 * @param peer
 * @return
 */
bool AddHelper::copybackhandle(QString plugin){
    bool found = false;
    QString build = QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "build";
    QString mainDir = QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "SIL" + QDir::separator() + plugin;
    QFileInfoList fileList = QDir(mainDir).entryInfoList(QDir::NoDotAndDotDot|QDir::AllEntries);
    for(int i = 0; i < fileList.length(); i++){
        if(fileList.at(i).completeSuffix() == "pro"){
            QString proFilestd = fileList.at(i).filePath();
            QFile proFile(proFilestd);
            proFile.open(QIODevice::ReadWrite);
            QTextStream in (&proFile);
            while(!in.atEnd()){
                QString content = in.readLine();
                if(content.contains("TARGET = ../../build/")){
                    QString fileBase = content.remove("TARGET = ../../build/");
                    QString soName = "lib" + fileBase + ".so";
                    if(QFile(build + QDir::separator() + soName).exists()){
                        QFile(build + QDir::separator() + soName).remove();
                    }
                    found = QFile().rename(mainDir + QDir::separator() + soName, build + QDir::separator() + soName);
                }
            }
            proFile.close();
        }
    }
    return found;
}
