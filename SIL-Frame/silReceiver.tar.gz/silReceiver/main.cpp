#include <QCoreApplication>
#include <QString>
#include <QStringList>
#include <QDir>
#include <QFileInfoList>
#include "addhelper.h"
#include "removehelper.h"
#include <QProcess>


/**
 * @brief handles the add and remove of new plugins
 * @param argc
 * @param argv
 * @return
 */
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    QString opt = a.arguments().at(1);
    QString plugin = a.arguments().at(2);
    AddHelper addhelp;
    RemoveHelper removehelp;

    QString path = "~/sil/SIL";
    QString pluginPath = path + "/" + plugin;

    if(opt == "add"){
        QString cdCommand = " cd " + pluginPath + "; qmake; make clean -s; make -s";
        std::string cdCommandStd = cdCommand.toStdString();
        int state = system(cdCommandStd.c_str());
        if(state == 0){
            if(addhelp.listRenew(plugin)){
                if(addhelp.configDir(plugin)){
                    if(addhelp.copyhandle(plugin)){
                        return state;
                    } else {
                        return -1;
                    }
                } else {
                    return -1;
                }
            } else {
                return -1;
            }
        } else {
            return -1;
        }
    }
    if(opt == "copy"){
        if(addhelp.listRenew(plugin)){
            if(addhelp.configDir(plugin)){
                if(addhelp.copybackhandle(plugin)){
                    return 0;
                } else {
                    return -1;
                }
            } else {
                return -1;
            }
        } else {
            return -1;
        }
    }
    if(opt == "rm"){
        if(removehelp.removeIniAndSo(plugin)){
            if(removehelp.remove(plugin)){
                if(removehelp.listRemove(plugin)){
                    return 0;
                } else {
                    return -1;
                }
            } else {
                return -1;
            }
        } else {
            return -1;
        }
    }
    return 0;
}






