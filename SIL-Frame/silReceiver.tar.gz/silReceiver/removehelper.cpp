#include "removehelper.h"
#include <QDir>
#include <QString>
#include <QTextStream>
#include <QStringList>
#include <QDebug>

/**
 * @brief RemoveHelper::RemoveHelper
 */
RemoveHelper::RemoveHelper()
{

}

/**
 * @brief Removes the Plugin Binarys and the lib-Dir
 * @param plugin
 * @return
 */
bool RemoveHelper::remove(QString plugin){
    QString buildDir = QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "build" + QDir::separator() + plugin;
    QString plugDir = QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "SIL" + QDir::separator() + plugin;
    bool one = QDir(buildDir).removeRecursively();
    bool two = QDir(plugDir).removeRecursively();
    return(one && two);
}

/**
 * @brief Removes the Plugin from the plugin_list
 * @param plugin
 * @return
 */
bool RemoveHelper::listRemove(QString plugin){
    QFile list(QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "SIL" + QDir::separator() + "plugin_list");
    if(list.exists()){
        if(!list.open(QIODevice::ReadWrite | QIODevice::Text)) {
            qWarning() << "Could not open plugin_list";
            return false;
        }
        QTextStream in(&list);
        QStringList fields;
        while(!in.atEnd()){
            QString line = in.readLine();
            if(line != plugin){
                fields.append(line);
            }
        }
        list.resize(0);
        fields.removeDuplicates();
        for(int j = 0; j < fields.length(); j++){
            in << fields.at(j) << "\n";
        }
        list.close();
    }
    return true;
}

/**
 * @brief RemoveHelper::removeIniAndSo
 * @param plugin
 * @return
 */
bool RemoveHelper::removeIniAndSo(QString plugin){
    bool found = false;
    QString build = QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "build";
    QString mainDir = QDir::homePath() + QDir::separator() + "sil" + QDir::separator() + "SIL" + QDir::separator() + plugin;
    QFileInfoList fileList = QDir(mainDir).entryInfoList(QDir::NoDotAndDotDot|QDir::AllEntries);
    for(int i = 0; i < fileList.length(); i++){
        if(fileList.at(i).completeSuffix() == "pro"){
            QString proFilestd = fileList.at(i).filePath();
            QFile proFile(proFilestd);
            proFile.open(QIODevice::ReadWrite);
            QTextStream in (&proFile);
            while(!in.atEnd()){
                QString content = in.readLine();
                if(content.contains("TARGET = ../../build/")){
                    QString fileBase = content.remove("TARGET = ../../build/");
                    QString soName = "lib" + fileBase + ".so";
                    found = QFile().remove(build + QDir::separator() + soName);
                }
            }
            proFile.close();
        }
        if(fileList.at(i).completeSuffix() == "ini"){
            QString iniFile = fileList.at(i).fileName();
            QFile().remove(build + QDir::separator() + iniFile);
        }
    }
    return found;
}
