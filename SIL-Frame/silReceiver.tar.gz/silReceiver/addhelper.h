#ifndef ADDHELPER_H
#define ADDHELPER_H

#include <QObject>
#include <QString>

class AddHelper
{
public:
    AddHelper();
    bool listRenew(QString);
    bool configDir(QString);
    bool copyhandle(QString);
    bool copybackhandle(QString);
};

#endif // ADDHELPER_H
