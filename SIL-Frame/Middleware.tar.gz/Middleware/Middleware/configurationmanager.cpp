#include "configurationmanager.h"

ConfigurationManager::ConfigurationManager(){
    //seeding
    m_configuration = new QSettings("Universtity of Bremen - Cognitive Systems", "SIL Middleware");
    m_configuration->clear();
    if(REQUIRED_CONFIG_ENTRIES.size() == REQUIRED_CONFIG_ENTRIES_DEFAULTS.size()){
        for(int i = 0; i < REQUIRED_CONFIG_ENTRIES.size(); i++){
            m_configuration->setValue(REQUIRED_CONFIG_ENTRIES.at(i), REQUIRED_CONFIG_ENTRIES_DEFAULTS.at(i));
        }
    }
}

ConfigurationManager::~ConfigurationManager(){
    if(m_configuration)
        delete m_configuration;
}

void ConfigurationManager::initialize(){}
void ConfigurationManager::initialize(int argc, char **argv){
    if(argc == 3 && QString(argv[1]).compare("-configfile",Qt::CaseInsensitive) == 0){
        if(m_configuration) delete m_configuration;
        m_configuration = new QSettings(QString(argv[2]), QSettings::IniFormat);
        m_configuration->sync();
    }else{
        QRegExp entry (".+=.+");
        for(int i = 1; i < argc; i++){
            if(QString(argv[i]).compare("-configstring", Qt::CaseInsensitive) == 0 && argc > ++i){
                foreach(QString configline, QString(argv[i]).split("\n", QString::SkipEmptyParts)){
                    configline = configline.trimmed();
                    if(entry.exactMatch(configline)){
                      QStringList configentry = configline.split("=");
#ifdef QT_DEBUG
                      logDebug("ConfigurationManager", "Setting: '" + configentry.at(0) + "' to '" + configentry.at(1) + "'");
#endif
                      m_configuration->setValue(configentry.at(0), configentry.at(1));
                    }
                }
            }else{
                foreach(QString patternExp, CONFIG_ENTRIES){
                    QRegExp pattern("-" + patternExp);
                    if(pattern.exactMatch(argv[i]) && argc > ++i){
#ifdef QT_DEBUG
                        logDebug("ConfigurationManager", "Setting: '" + patternExp + "' to '" + argv[i] + "'");
#endif
                        m_configuration->setValue(patternExp, argv[i]);
                        break;
                    }
                }
            }
        }
    }
    if(m_configuration->value(CONF_BASE_IP).toString().isEmpty() && !m_configuration->value(CONF_BASE_IFACE).toString().isEmpty()){
        m_configuration->setValue(CONF_BASE_IP, ownIpAddress(m_configuration->value(CONF_BASE_IFACE).toString()));
    }
}

QString ConfigurationManager::getEntry(const QString key){
    return m_configuration->value(key).toString();
}

void ConfigurationManager::setEntry(const QString key, const QString value){
    m_configuration->setValue(key, value);
}

void ConfigurationManager::setConfigurationFile(const QString file){
    m_file = file;
}

QString ConfigurationManager::toString(){
    QString msg = "\n";

    QStringList dynamicBasicRequirements (REQUIRED_CONFIG_ENTRIES);
    if(m_configuration->value(CONF_UI_USED).toString().compare("true", Qt::CaseInsensitive) == 0){
        dynamicBasicRequirements.append(CONF_UI_WIDTH);
        dynamicBasicRequirements.append(CONF_UI_HEIGHT);
    }

    foreach(QString pattern, CONFIG_ENTRIES){
        if(!m_configuration->value(pattern).toString().isEmpty()){
            msg = msg + "Configuration entry for: '" + pattern + "' -> '" + m_configuration->value(pattern).toString() + "'\n";
        }
    }
    if(m_configuration->value("ip").toString().isEmpty()){
        msg = msg + "No ip address could be determined.\n";
    }else{
        msg = msg + "Ip address is '" + m_configuration->value(CONF_BASE_IP).toString() + "'";
    }
    return msg;
}

bool ConfigurationManager::isValid(){
    bool valid = true;
    foreach(QString pattern, REQUIRED_CONFIG_ENTRIES){
        if(!pattern.isEmpty())
            valid = valid && !m_configuration->value(pattern).toString().isEmpty();
    }
    return valid;
}

system_mode_t ConfigurationManager::getMode(){
    system_mode_t mode = SIMULATED;
    if(m_configuration->value(CONF_BASE_MODE).toString().compare(BASE_MODE_NORMAL, Qt::CaseInsensitive) == 0){
        mode = NORMAL;
    } else if(m_configuration->value(CONF_BASE_MODE).toString().compare(BASE_MODE_SIMULATION, Qt::CaseInsensitive) == 0){
        mode = SIMULATED;
    }
    return mode;
}

void ConfigurationManager::syncConfiguration(){
    if(!m_file.isEmpty()){
        m_configuration->sync();
    }
}

QString ConfigurationManager::ownIpAddress(QString iface){
    struct ifaddrs * ifAddrStruct = NULL;
    struct ifaddrs * ifa = NULL;
    void * tmpAddrPtr = NULL;

    QString ip = "";

    getifaddrs(&ifAddrStruct);

    for (ifa = ifAddrStruct; ifa != NULL; ifa = ifa->ifa_next) {
      if (ifa->ifa_addr->sa_family == AF_INET) { // check it is IP4
        // is a valid IP4 Address
        tmpAddrPtr = &((struct sockaddr_in *) ifa->ifa_addr)->sin_addr;
        char addressBuffer[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);

        QString tmp_iface(ifa->ifa_name);
        if (tmp_iface == iface) {
          ip = addressBuffer;
        }
      } /* else if (ifa->ifa_addr->sa_family == AF_INET6) { // check it is IP6 -> requires check in GroupComCtrl
        // is a valid IP6 Address
        tmpAddrPtr = &((struct sockaddr_in *) ifa->ifa_addr)->sin_addr;
        char addressBuffer[INET6_ADDRSTRLEN];
        inet_ntop(AF_INET6, tmpAddrPtr, addressBuffer, INET6_ADDRSTRLEN);

        QString tmp_iface(ifa->ifa_name);
        if (tmp_iface == iface) {
          ip = addressBuffer;
        }
      } */
    }
    if (ifAddrStruct != NULL)
      freeifaddrs(ifAddrStruct);

    if (ip.isEmpty()) {
      ip = "127.0.0.1";
    }

    return ip;
}

void ConfigurationManager::processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message){
#ifdef QT_DEBUG
    logDebug("ConfigurationManagement", message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif

    QStringList msg = message.split(";");
    if(msg.size() >= 1 && msg.first().compare("get", Qt::CaseInsensitive) == 0){
        if(msg.size() == 1){
            send(senderpeer, senderplugin, receiverpeer, receiverplugin, id, false, m_configuration->allKeys().join(";"));
            return;
        } else if(msg.size() == 2) {
            send(senderpeer, senderplugin, receiverpeer, receiverplugin, id, false, getEntry(msg.last()));
            return;
        }
    } else { // Rest in separate else block dut to possible reply reqyest
        if(msg.size() == 3 && msg.first().compare("post", Qt::CaseInsensitive) == 0){
            setEntry(msg.at(1), msg.at(2));
        } else if(msg.size() == 3 && msg.first().compare("put", Qt::CaseInsensitive) == 0){
            setEntry(msg.at(1), msg.at(2));
        } else if(msg.size() == 3 && msg.first().compare("patch", Qt::CaseInsensitive) == 0){
            setEntry(msg.at(1), msg.at(2));
        } else if(msg.size() == 2 && msg.first().compare("delete", Qt::CaseInsensitive) == 0){
            if(!getEntry(msg.at(1)).isEmpty()){
                m_configuration->remove(msg.at(1));
            }
        } else if(msg.size() == 1 && msg.first().compare("synchronize", Qt::CaseInsensitive) == 0){
            if(!m_file.isEmpty()){
                m_configuration->sync();
            }
        } else if(msg.size() == 2 && msg.first().compare("filename", Qt::CaseInsensitive) == 0){
            m_file = msg.last();
        } else {
            logWarning("ConfigurationManagement", "(" + timestamp.toString(Qt::ISODate) + ") Received invalid message to: " + receiverplugin + " from: " + senderpeer + "; " + senderplugin + " with message: " + message);
        }
        if(expectingReply){
            send(senderpeer, senderplugin, receiverpeer, receiverplugin, id, false, "Message received");
        }
    }
}
