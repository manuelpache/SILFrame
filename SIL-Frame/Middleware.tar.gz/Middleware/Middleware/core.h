#ifndef CORE_H
#define CORE_H

#include "middleware.h"
#include "configurationmanager.h"
#include "logger.h"
#include "peermanager.h"
#include "localcommunicationmanager.h"
#include "pluginmanager.h"
#include "guimanager.h"
#include "groupcommunicationserver.h"
#include "groupcommunicationsender.h"

#include <QObject>
#include <QApplication>
#include <QTimer>
#include <QThread>

class Core: public QObject {
    Q_OBJECT

public:
    Core(int argc, char **argv, QApplication *qapp);
    virtual ~Core();

protected:
    /*!
     * \brief logDebug
     * \param message
     */
    void logDebug(QString message);
    /*!
     * \brief logWarning
     * \param message
     */
    void logWarning(QString message);
    /*!
     * \brief logError
     * \param message
     */
    void logError(QString message);

    /*!
     * \brief setupBasicConnections
     * \param sender
     */
    void setupLoggerConnections(const Middleware *sender);

    /*!
     * \brief setupLocalComCtrlConnections
     * \param sender
     */
    void setupLocalComCtrlConnections(const Middleware *sender);

    /*!
     * \brief setupLocalComCtrlOutgoingConnections
     */
    void setupLocalComCtrlOutgoingConnections();

    /*!
     * \brief setupConfiguration
     * \param argc
     * \param argv
     * \return
     */
    system_mode_t setupConfiguration(int argc, char **argv);

    /*!
     * \brief setupPlugins
     */
    void setupPlugins();
    /*!
     * \brief seedInitialData
     */
    void seedInitialData();
    /*!
     * \brief startInitialPlugins
     */
    void startInitialPlugins();

protected slots:
    /*!
     * \brief systemInitiation
     */
    void systemInitiation();

    void systemShutdown();

private:
    QApplication *m_qapp;

    Logger *m_logger;
    ConfigurationManager *m_configuration_manager;
    PeerManager *m_peer_manager;
    PluginManager *m_plugin_manager;
    GUIManager *m_gui_manager;
    LocalCommunicationManager *m_local_communication_manager;
    GroupCommunicationServer *m_group_communication_server;
    GroupCommunicationSender *m_group_communication_sender;
};

#endif // CORE_H
