#ifndef PLUGINMANAGER_H
#define PLUGINMANAGER_H

#include "middleware.h"
#include "guimanager.h"
#include "logger.h"
#include "localcommunicationmanager.h"

#include <QMetaType>
#include <QByteArray>
#include <QMap>
#include <QDir>
#include <QPluginLoader>
#include <QPair>
#include <QTimer>

class PluginManager: public Middleware{
    Q_OBJECT

signals:
    void sendToPlugin(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

public:
    PluginManager(system_mode_t mode, GUIManager *gui);
    virtual ~PluginManager();

    void initialize();
    void detectPlugins();
    void autostart();

protected slots:
    void processPluginMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

protected:
    void setupPlugin(Plugin *plugin);
    void shutdown();

    Plugin* loadPlugin(QString file);
    bool reloadPlugin(QString id);

    void setupPlugin(QString id);
    void shutdownPlugin(QString id);
    void startPlugin(QString id);
    void stopPlugin(QString id);

    bool isAllowed(QString file, Plugin *plugin);
    bool isCompatable(Plugin *plugin);
    bool checkDependencies(Plugin *plugin);

    void processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);
    void relayToPlugin(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

private:
    system_mode_t m_mode;
    GUIManager *m_gui;

    QMap<QString, Plugin*> m_plugins;
    QMap<QString, QThread*> m_pluginThreads;
    QMap<QString, QString> m_pluginFiles;

    QStringList m_autostartPlugins;
    QStringList m_widgetPlugins;
    QStringList m_restrictions;

    QStringList m_all_possible_plugins;
};

#endif // PLUGINMANAGER_H
