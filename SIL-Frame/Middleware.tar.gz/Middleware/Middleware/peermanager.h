#ifndef PEERMANAGER_H
#define PEERMANAGER_H

#include "middleware.h"

class PeerManager: public Middleware {
    Q_OBJECT

public:
    PeerManager();
    virtual ~PeerManager();

    void initialize();

protected:
    /*!
     * \brief implementation of inherited method
     */
    void processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

    /*!
     * \brief resolvePeername
     * \param peername
     * \return
     */
    QString resolvePeername(QString peername);
    /*!
     * \brief getKnownPeers
     * \return
     */
    QString getKnownPeers();
    /*!
     * \brief rememberPeer
     * \param peer
     */
    void rememberPeer(QString peer);
    /*!
     * \brief rememberPeer
     * \param peername
     * \param address
     */
    void rememberPeer(QString peername, QString address);
    /*!
     * \brief forgetPeer
     * \param peername
     */
    void forgetPeer(QString peername);

private:
    QMap<QString, QString> *m_addressTable;
    bool m_useRESTDatastore;
};

#endif // PEERMANAGER_H
