#include "middleware.h"

Middleware::Middleware(): m_currentSynchronousMessages(new QMap<QString, QPair<QSemaphore*, QString> >){

}

Middleware::~Middleware(){

}

QString Middleware::getVersion(){
    return SIL_VERION_ID;
}

void Middleware::receiveMessage(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectingReply, const QString message){
    if(!m_currentSynchronousMessages->isEmpty() && m_currentSynchronousMessages->contains(id)){
#ifdef QT_DEBUG
    logDebug(SIL_MIDDLEWARE, "Received response: " + message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif
        //handle synchronous messages
        QPair<QSemaphore*, QString> request = m_currentSynchronousMessages->value(id);
        m_currentSynchronousMessages->remove(id);
        request.second = message;
        m_currentSynchronousMessages->insert(id, request);
        request.first->release();
    }else{
        processMessage(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);
    }
}

void Middleware::processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message){
#ifdef QT_DEBUG
    logDebug("SIL_MIDDLEWARE", "NOT HANDLED: " + message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif
    if(expectingReply){
        send(senderpeer, senderplugin, receiverpeer, receiverplugin, id, false, message);
    }
}

void Middleware::send(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QString id, const QString message){
    emit sendMessage(receiverpeer, receiverplugin, senderpeer, senderplugin, QDateTime::currentDateTime(), id, false, message);
}

void Middleware::send(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QString id, const bool expectinReply, const QString message){
    emit sendMessage(receiverpeer, receiverplugin, senderpeer, senderplugin, QDateTime::currentDateTime(), id, expectinReply, message);
}

void Middleware::send(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QDateTime time, const QString id, const bool expectinReply, const QString message){
    emit sendMessage(receiverpeer, receiverplugin, senderpeer, senderplugin, time, id, expectinReply, message);
}

QString Middleware::syncSend(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QString message){
    QString uuid = QUuid::createUuid().toString();
    QSemaphore *locallock = new QSemaphore();
    m_currentSynchronousMessages->insert(uuid, qMakePair(locallock, QString()));
    emit sendMessage(receiverpeer, receiverplugin, senderpeer, senderplugin, QDateTime::currentDateTime(), uuid, true, message);
    locallock->acquire();
    QPair<QSemaphore*, QString> reply = m_currentSynchronousMessages->value(uuid);
    delete locallock;
    return reply.second;
}

QString Middleware::getConfiguration(QString key, QString sender){
    return syncSend(ADDR_PEER_LOCAL, ADDR_CONFIGURATION, ADDR_PEER_LOCAL, sender, "get;" + key);
}

QString Middleware::message2str(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectingReply, const QString message){
    return ("At " + timestamp.toString(Qt::ISODate) + " received message to: " + receiverpeer + ";" + receiverplugin + " from: " + senderpeer + ";" + senderplugin + " with id: > " + id + " < and message: > " + message + " < -> reply requested: " + (expectingReply? "true" : "false"));
}


void Middleware::logDebug(QString sender, QString message){
    emit loggingDebug(sender, message);
}

void Middleware::logWarning(QString sender, QString message){
    emit loggingWarning(sender, message);
}

void Middleware::logError(QString sender, QString message){
    emit loggingError(sender, message);
}
