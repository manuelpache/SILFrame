#ifndef ANNOUNCEMENTMANAGER_H
#define ANNOUNCEMENTMANAGER_H

#include <QObject>
#include <QString>
#include <QMap>
#include <QList>
#include <QPair>
#include <QDateTime>

class AnnouncementManager: public QObject{
    Q_OBJECT

signals:
    void send(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

public:
    AnnouncementManager();
    virtual ~AnnouncementManager();

    void subscribe(QString peer, QString plugin, QString topic);
    void unsubscribe(QString peer, QString plugin, QString topic);

    void announce(QString topic, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, QString message);

private:
    QMap<QString, QList<QPair<QString, QString> >* > m_subscriptions;
};

#endif // ANNOUNCEMENTMANAGER_H
