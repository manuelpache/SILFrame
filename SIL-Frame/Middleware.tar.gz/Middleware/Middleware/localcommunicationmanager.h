#ifndef LOCALCOMMUNICATIONMANAGER_H
#define LOCALCOMMUNICATIONMANAGER_H

#include "middleware.h"
#include "announcementmanager.h"

#include <QUuid>
#include <QPair>

class LocalCommunicationManager: public Middleware{
    Q_OBJECT

signals:
    /*!
     * \param receiverpeer
     * \param receiverplugin
     * \param senderpeer
     * \param senderplugin
     * \param timestamp
     * \param id
     * \param expectingReply
     * \param message
     */
    void sendToConfiguration(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);
    void sendToLogger(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);
    void sendToGUI(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);
    void sendToPluginManager(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);
    void sendToPlugin(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);
    void sendToPeerManager(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);
    void sendToGroupCommunicationReceiver(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);
    void sendToGroupCommunicationSender(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

    void cmdShutdown();

public:
    LocalCommunicationManager();
    virtual ~LocalCommunicationManager();

    void initialize();

protected:
    void processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

    void middlewareCMD(QString cmd);

private:
    AnnouncementManager *m_announcement;
};

#endif // LOCALCOMMUNICATIONMANAGER_H
