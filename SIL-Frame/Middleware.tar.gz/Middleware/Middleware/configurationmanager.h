#ifndef CONFIGURATIONMANAGER_H
#define CONFIGURATIONMANAGER_H

#include "middleware.h"

#include <QSettings>
#include <QRegExp>

#include <iostream>
#include <sys/types.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>


#include <ifaddrs.h>
//#include "android-ifaddrs/ifaddrs.h"


class ConfigurationManager: public Middleware{
    Q_OBJECT

public:
    ConfigurationManager();
    virtual ~ConfigurationManager();

    void initialize();
    void initialize(int argc, char **argv);

    /*!
     * \brief getEntry
     * \param key
     * \return
     */
    QString getEntry(const QString key);
    /*!
     * \brief setEntry
     * \param key
     * \param value
     */
    void setEntry(const QString key, const QString value);

    /*!
     * \brief setConfigurationFile
     * \param file
     */
    void setConfigurationFile(const QString file);

    /*!
     * \brief toString
     * \return
     */
    QString toString();
    /*!
     * \brief isValid
     * \return
     */
    bool isValid();

    /*!
     * \brief getMode
     * \return
     */
    system_mode_t getMode();

protected:
    /*!
     * \brief implementation of inherited method
     */
    void processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

    /*!
     * \brief syncConfiguration
     */
    void syncConfiguration();
    /*!
     * \brief ownIpAddress
     * \param iface
     * \return
     */
    QString ownIpAddress(QString iface);

private:
    QString m_file;
    QSettings *m_configuration;
    QString m_ip;
};

#endif // CONFIGURATIONMANAGER_H
