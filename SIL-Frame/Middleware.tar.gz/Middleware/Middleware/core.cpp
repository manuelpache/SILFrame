#include "core.h"

Core::Core(int argc, char **argv, QApplication *qapp): m_qapp(qapp), m_logger(new Logger()), m_configuration_manager(0) {
    logDebug("Setting up SIL middleware");

    logDebug("loading configuration");
    system_mode_t mode = setupConfiguration(argc, argv);

    logDebug("setup local communication control");
    m_local_communication_manager = new LocalCommunicationManager();
    // connect Middleware CMDs
    QObject::connect(m_local_communication_manager, SIGNAL(cmdShutdown()), this, SLOT(systemShutdown()));
    // resume normal setup routine
    setupLoggerConnections(m_local_communication_manager);
    setupLocalComCtrlConnections(m_configuration_manager);

    logDebug("setup peer manager");
    m_peer_manager = new PeerManager();
    setupLoggerConnections(m_peer_manager);
    setupLocalComCtrlConnections(m_peer_manager);

    logDebug("setup GUI");
    if(m_configuration_manager->getEntry(CONF_UI_USED).compare("true", Qt::CaseInsensitive) == 0){
        m_gui_manager = new GUIManager(mode);
        setupLoggerConnections(m_gui_manager);
        setupLocalComCtrlConnections(m_gui_manager);
        QObject::connect(m_local_communication_manager, SIGNAL(sendToGUI(QString,QString,QString,QString,QDateTime,QString,bool,QString)), m_gui_manager, SLOT(receiveMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)));
    }else{
        m_gui_manager = 0;
    }

    logDebug("setup Plug-in system");
    m_plugin_manager = new PluginManager(mode, m_gui_manager);
    setupLoggerConnections(m_plugin_manager);
    setupLocalComCtrlConnections(m_plugin_manager);

    logDebug("setup group server");
    // handled special as diamant inheritence is not possible in QT
    int port = m_configuration_manager->getEntry(CONF_BASE_PORT).toInt();
    QString peerid = m_configuration_manager->getEntry(CONF_BASE_PEERID);
    //FIXME static timeout setting...
    m_group_communication_server = new GroupCommunicationServer(port, peerid, TIMEOUT);
    setupLoggerConnections(m_group_communication_server);
    setupLocalComCtrlConnections(m_group_communication_server);

    //QThread thread;
    //m_group_communication_server->moveToThread(&thread);
    m_group_communication_server->initialize();
    //thread.start();
    //QTimer::singleShot(20, m_group_communication_server, SLOT(setupServer()));


    logDebug("setup group sender");
    m_group_communication_sender = new GroupCommunicationSender();
    setupLoggerConnections(m_group_communication_sender);
    setupLocalComCtrlConnections(m_group_communication_sender);

    setupLocalComCtrlOutgoingConnections();

    logDebug("Scheduling system initiation");
    QTimer::singleShot(20, this, SLOT(systemInitiation()));
    logDebug("Initiating main event loop");
    qapp->exec();
    logDebug("Exiting main event loop");
}

Core::~Core(){
    if(m_logger) delete m_logger;
    if(m_configuration_manager) delete m_configuration_manager;
    if(m_peer_manager) delete m_peer_manager;
    if(m_plugin_manager) delete m_plugin_manager;
    if(m_gui_manager) delete m_gui_manager;
    if(m_local_communication_manager) delete m_local_communication_manager;
    if(m_group_communication_server) delete m_group_communication_server;
    if(m_group_communication_sender) delete m_group_communication_sender;
}

void Core::logDebug(QString message){
#ifdef QT_DEBUG
    if(m_logger){
        m_logger->logDebugMessage("Core", message);
    }
#endif
}

void Core::logWarning(QString message){
    if(m_logger){
        m_logger->logWarningMessage("Core", message);
    }
}

void Core::logError(QString message){
    if(m_logger){
        m_logger->logErrorMessage("Core", message);
    }
}

void Core::setupLoggerConnections(const Middleware *sender){
    if(m_logger){
        QObject::connect(sender, SIGNAL(loggingDebug(QString,QString)), m_logger, SLOT(logDebugMessage(QString,QString)));
        QObject::connect(sender, SIGNAL(loggingWarning(QString,QString)), m_logger, SLOT(logWarningMessage(QString,QString)));
        QObject::connect(sender, SIGNAL(loggingError(QString,QString)), m_logger, SLOT(logErrorMessage(QString,QString)));
    }
}

void Core::setupLocalComCtrlConnections(const Middleware *sender){
    if(m_local_communication_manager){
        QObject::connect(sender, SIGNAL(sendMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)), m_local_communication_manager, SLOT(receiveMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)));
    }
}

void Core::setupLocalComCtrlOutgoingConnections(){
    logDebug("setup of outgoing connections from local communication control");
    QObject::connect(m_local_communication_manager, SIGNAL(sendToConfiguration(QString,QString,QString,QString,QDateTime,QString,bool,QString)), m_configuration_manager, SLOT(receiveMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)));

    QObject::connect(m_local_communication_manager, SIGNAL(sendToLogger(QString,QString,QString,QString,QDateTime,QString,bool,QString)), m_logger, SLOT(receiveMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)));

    QObject::connect(m_local_communication_manager, SIGNAL(sendToPluginManager(QString,QString,QString,QString,QDateTime,QString,bool,QString)), m_plugin_manager, SLOT(receiveMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)));

    //this is not the best way
    QObject::connect(m_local_communication_manager, SIGNAL(sendToPlugin(QString,QString,QString,QString,QDateTime,QString,bool,QString)), m_plugin_manager, SLOT(receiveMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)));

    QObject::connect(m_local_communication_manager, SIGNAL(sendToPeerManager(QString,QString,QString,QString,QDateTime,QString,bool,QString)), m_peer_manager, SLOT(receiveMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)));

    QObject::connect(m_local_communication_manager, SIGNAL(sendToGroupCommunicationSender(QString,QString,QString,QString,QDateTime,QString,bool,QString)), m_group_communication_sender, SLOT(receiveMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)));
}

void Core::systemInitiation(){
    logDebug("initialize components");
    if(m_logger) m_logger->initialize();
    if(m_configuration_manager) m_configuration_manager->initialize();
    if(m_local_communication_manager) m_local_communication_manager->initialize();
    if(m_gui_manager) m_gui_manager->initialize();
    if(m_plugin_manager) m_plugin_manager->initialize();
    if(m_group_communication_sender) m_group_communication_sender->initialize();

    if(m_peer_manager && m_plugin_manager){
        logDebug("final setup and seeding");
        m_peer_manager->initialize();
        seedInitialData();
        setupPlugins();
        // initialize again to allow Plugin data storage
        m_peer_manager->initialize();
        seedInitialData();
        startInitialPlugins();
    } else {
        logError("Failed to conduct final setup");
        exit(-1);
    }    
    logDebug("Setup completed - Middleware initiated");
}

void Core::systemShutdown(){
    m_qapp->quit();
}

system_mode_t Core::setupConfiguration(int argc, char **argv){
    m_configuration_manager = new ConfigurationManager();
    setupLoggerConnections(m_configuration_manager);
    m_configuration_manager->initialize(argc, argv);
    if(!m_configuration_manager || !m_configuration_manager->isValid()){
#ifdef QT_DEBUG
        if(!m_configuration_manager->isValid()){
            logError("ConfigurationManager was provided an invalid configuration.");
        }
#endif
        logError("ConfigurationManager could not be instanciated, available configuration => \n" + m_configuration_manager->toString());
        exit(-1);
    } else {
        logDebug(m_configuration_manager->toString());
        if(!m_configuration_manager->getEntry(CONF_BASE_PEERID).isEmpty()){
            m_logger->setLogPrefix(m_configuration_manager->getEntry(CONF_BASE_PEERID));
        }
        if(!m_configuration_manager->getEntry(CONF_BASE_LOGFILTER).isEmpty()){
            m_logger->setLogFilter(m_configuration_manager->getEntry(CONF_BASE_LOGFILTER));
        }
    }
    return m_configuration_manager->getMode();
}

void Core::setupPlugins(){
    logDebug("initial detection of plug-ins");
    try{
        m_plugin_manager->detectPlugins();
    }catch(...){
        logError("Initial detection of plug-ins failed");
    }
}

void Core::seedInitialData(){
    logDebug("initial seeding of data");
    foreach(QString peer, m_configuration_manager->getEntry(CONF_BASE_PEERS).split(";")){
        m_peer_manager->receiveMessage(ADDR_PEER_LOCAL, ADDR_PEERMANAGER, ADDR_PEER_LOCAL, "STARTUP", QDateTime::currentDateTime(), "seeding", false, "post;" + peer);
    }
}

void Core::startInitialPlugins(){
    logDebug("initial setup and start of plug-ins");
    try{
        m_plugin_manager->autostart();
    }catch(...){
        logError("Autostart of plug-ins failed");
    }
}

int main(int argc, char **argv){
    QApplication qapp(argc, argv);
    Core *core = new Core(argc, argv, &qapp);
    if(core){
        delete core;
        exit(0);
    } else {
        exit (-1);
    }
}
