#ifndef GROUPCOMMUNICATIONSENDER_H
#define GROUPCOMMUNICATIONSENDER_H

#include "middleware.h"

#include <QString>
#include <QStringList>
#include <QByteArray>
#include <QTcpSocket>
#include <QRegExp>
#include <QDateTime>
#include <QList>
#include <QDataStream>

class GroupCommunicationSender: public Middleware{
    Q_OBJECT

public:
    GroupCommunicationSender();
    virtual ~GroupCommunicationSender();

    void initialize();

protected:
    /*!
     * \brief implementation of inherited method
     */
    void processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);
    QString requestPeer(QString peerid);

    bool transmitMessage(QTcpSocket *socket, const QString peer, const QString plugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectReply, QString message);
    bool transmit(QTcpSocket *socket, const QStringList *header, const QList<QByteArray> *data);
    void transmitData(QTcpSocket *socket, QByteArray data);
    bool generateHeader(QStringList *header, const QString peer, const QString plugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectReply);
    void openConnection(QTcpSocket *socket, QString address, int port);
    void closeConnection(QTcpSocket* socket);
    bool isValidHeader(const QStringList *header);
    bool isValidConnection(const QTcpSocket *socket);

private:
    QString m_peerid;
    int m_timeout;
};

#endif // GROUPCOMMUNICATIONSENDER_H
