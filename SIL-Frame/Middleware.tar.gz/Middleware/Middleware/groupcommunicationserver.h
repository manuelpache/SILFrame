#ifndef GROUPCOMMUNICATIONSERVER_H
#define GROUPCOMMUNICATIONSERVER_H

#include "middleware.h"

#include "localcommunicationmanager.h"
#include "logger.h"
//#include "groupcommunicationreceiver.h"

#include <QString>
#include <QStringList>
#include <QByteArray>
#include <QTcpSocket>
#include <QTcpServer>
#include <QRegExp>
#include <QDateTime>
#include <QList>
#include <QObject>
#include <QDataStream>

//class GroupCommunicationServer: public QTcpServer {
class GroupCommunicationServer: public Middleware {
    Q_OBJECT

public:
    GroupCommunicationServer(int port, QString peerid, int timeout);
    virtual ~GroupCommunicationServer();

    void initialize();
    void processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

public slots:
    void incoming();

protected:
    //void connectThread(GroupCommunicationReceiver *thread);

    bool isValidHeader(const QStringList *header);
    bool isValidConnection(const QTcpSocket *socket);
    void closeConnection(QTcpSocket* socket);
    bool readIncomingMessage(QTcpSocket *socket, QStringList *msg);
    QByteArray readIncomingData(QTcpSocket *socket);

private:
    QTcpServer *m_server;
    int m_port;
    QString m_peerid;
    int m_timeout;
};

#endif // GROUPCOMMUNICATIONSERVER_H
