#ifndef GUIMANAGER_H
#define GUIMANAGER_H

#include "middleware.h"

#include <QMainWindow>
#include <QStackedWidget>
#include <QImage>
#include <QtSvg/QSvgRenderer>
#include <QtSvg/QSvgWidget>
#include <QPainter>
#include <QLabel>
#include <QPixmap>

class GUIManager: public Middleware {
    Q_OBJECT

public:
    GUIManager(mode_t mode);
    virtual ~GUIManager();

    void initialize();

    /*!
     * \brief addPlugin
     * \param plugin
     */
    void addPlugin(Plugin *plugin);

protected:
    /*!
     * \brief implementation of inherited method
     */
    void processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

    /*!
     * \brief removePlugin
     * \param pluginid
     */
    void removePlugin(QString pluginid);
    /*!
     * \brief showPlugin
     * \param pluginid
     */
    void showPlugin(QString pluginid);
    /*!
     * \brief hidePlugin
     * \param pluginid
     */
    void hidePlugin(QString pluginid);

    /*!
     * \brief renderSVGLogo
     * \param path
     * \param width
     * \param height
     * \return
     */
    QImage renderSVGLogo(QString path, int width, int height);
    double maxScaleFactor(int width, int height, int maxW, int maxH);

private:
    mode_t m_mode;
    int m_width, m_height;
    QStackedWidget *m_stacked_widget;
    QMap<QString, QWidget*> m_widget_store;
    QStringList m_currently_displayed;
    QMainWindow *m_mainWindow;
};

#endif // GUIMANAGER_H
