#include "peermanager.h"

PeerManager::PeerManager(): m_addressTable(0), m_useRESTDatastore(false){
}

PeerManager::~PeerManager(){
    if(m_addressTable)
        delete m_addressTable;
}

void PeerManager::initialize(){
    m_useRESTDatastore = syncSend(ADDR_PEER_LOCAL, ADDR_PLUGINMANAGER, ADDR_PEER_LOCAL, ADDR_PEERMANAGER, "get;" + PLUGIN_NAME_RESTDATASTORE).compare(BASE_TRUE, Qt::CaseInsensitive) == 0;
    if(!m_useRESTDatastore){
#ifdef QT_DEBUG
        logDebug(SIL_PEERS, "Using private datastore");
#endif
        if(!m_addressTable)
            m_addressTable = new QMap<QString,QString>();
    } else {
#ifdef QT_DEBUG
        logDebug(SIL_PEERS, "Using RESTDataStore provided by plugin");
#endif
    }

    //seed addresses
    foreach(QString peer, getConfiguration(CONF_BASE_PEERS, ADDR_PEERMANAGER)){
        rememberPeer(peer);
    }
}

void PeerManager::processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message){
#ifdef QT_DEBUG
    logDebug(SIL_PEERS, message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif
    QStringList msg = message.split(";", QString::SkipEmptyParts);
    if(msg.size() >= 1 && msg.first().compare("get", Qt::CaseInsensitive) == 0){
        QString result = "";
        if(msg.size() > 1){
            for(int i = 1; i < msg.size(); i++){
                result += resolvePeername(msg.at(i)) + ";";
            }
        }else{
            result = getKnownPeers();
        }
        send(senderpeer, senderplugin, ADDR_PEER_LOCAL, ADDR_PEERMANAGER, id, result);
        return;
    }else if(msg.size() >= 2 && msg.first().compare("post", Qt::CaseInsensitive) == 0){
        for(int i = 1; i < msg.size(); i++){
            rememberPeer(msg.at(i));
        }
    }else if(msg.size() >= 2 && (msg.first().compare("patch", Qt::CaseInsensitive) == 0 || msg.first().compare("put", Qt::CaseInsensitive) == 0)){
        for(int i = 1; i < msg.size(); i++){
            rememberPeer(msg.at(i));
        }
    }else if(msg.size() >= 2 && msg.first().compare("delete", Qt::CaseInsensitive) == 0){
        for(int i = 1; i < msg.size(); i++){
            forgetPeer(msg.at(i));
        }
    }
    if(expectingReply){
        send(senderpeer, senderplugin, ADDR_PEER_LOCAL, ADDR_PEERMANAGER, id, "message received");
    }
}

QString PeerManager::resolvePeername(QString peername){
    if(m_useRESTDatastore){
        return syncSend(ADDR_PEER_LOCAL, PLUGIN_NAME_RESTDATASTORE, ADDR_PEER_LOCAL, ADDR_PEERMANAGER, "get;" + NAME_PEERSTORAGE + ";" + peername);
    }else if(m_addressTable){
        return m_addressTable->value(peername);
    }else{
        logError(SIL_PEERS, "No peer datastore available.");
        return "";
    }
}

QString PeerManager::getKnownPeers(){
    if(m_useRESTDatastore){
        return syncSend(ADDR_PEER_LOCAL, PLUGIN_NAME_RESTDATASTORE, ADDR_PEER_LOCAL, ADDR_PEERMANAGER, "get;" + NAME_PEERSTORAGE);
    }else if(m_addressTable){
        QString result = "";
        foreach(QString peer, m_addressTable->keys()){
            result += peer + ";";
        }
        return result;
    }else{
        logError(SIL_PEERS, "No peer datastore available.");
        return "";
    }
}

void PeerManager::rememberPeer(QString peer){
    QStringList addr = peer.split(":");
    if(addr.size() == 3){
        rememberPeer(addr.first(), peer);
    }
}

void PeerManager::rememberPeer(QString peername, QString address){
    if(m_useRESTDatastore){
        if(resolvePeername(peername).isEmpty()){
            send(ADDR_PEER_LOCAL, PLUGIN_NAME_RESTDATASTORE, ADDR_PEER_LOCAL, ADDR_PEERMANAGER, "insert address", "post;" + NAME_PEERSTORAGE + ";" + peername + ";" + address);
        }else{
            send(ADDR_PEER_LOCAL, PLUGIN_NAME_RESTDATASTORE, ADDR_PEER_LOCAL, ADDR_PEERMANAGER, "update address", "patch;" + NAME_PEERSTORAGE + ";" + peername + ";" + address);
        }
    }else if(m_addressTable){
        m_addressTable->insert(peername, address);
    }else{
        logError(SIL_PEERS, "No peer datastore available.");
    }
}

void PeerManager::forgetPeer(QString peername){
    if(m_useRESTDatastore){
        if(!resolvePeername(peername).isEmpty()){
            send(ADDR_PEER_LOCAL, PLUGIN_NAME_RESTDATASTORE, ADDR_PEER_LOCAL, ADDR_PEERMANAGER, "forget address", "delete;" + NAME_PEERSTORAGE + ";" + peername);
        }
    }else if(m_addressTable){
        if(m_addressTable->keys().contains(peername)){
            m_addressTable->remove(peername);
        }
    }else{
        logError(SIL_PEERS, "No peer datastore available.");
    }
}
