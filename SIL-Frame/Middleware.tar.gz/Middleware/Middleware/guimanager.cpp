#include "guimanager.h"

GUIManager::GUIManager(mode_t mode): m_mode(mode){
}

GUIManager::~GUIManager(){
}

void GUIManager::initialize(){  
    m_width = getConfiguration(CONF_UI_WIDTH, ADDR_GUI).toInt();
    m_height = getConfiguration(CONF_UI_HEIGHT, ADDR_GUI).toInt();
    m_mainWindow = new QMainWindow();
    m_stacked_widget = new QStackedWidget(m_mainWindow);
    m_stacked_widget->setMaximumSize(m_width, m_height);
    m_stacked_widget->setMinimumSize(m_width, m_height);

    if (m_mode != SIMULATED) {
        m_mainWindow->setWindowFlags(
        Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint);
        m_mainWindow->setWindowFlags(Qt::FramelessWindowHint);
    }

    QLabel *logo = new QLabel(m_stacked_widget);
    logo->resize(m_width, m_height);
    logo->setAlignment(Qt::AlignCenter);
    double scaleFactor = maxScaleFactor(RESOURCE_LOGO_SVG_WIDTH, RESOURCE_LOGO_SVG_HEIGHT, m_width, m_height);
    logo->setPixmap(QPixmap::fromImage(renderSVGLogo(RESOURCE_LOGO_SVG, RESOURCE_LOGO_SVG_WIDTH * scaleFactor, RESOURCE_LOGO_SVG_HEIGHT * scaleFactor)));

    //QSvgWidget *logo = new QSvgWidget(STR_RESOURCE_LOGO_SVG, m_stacked_widget);
    logo->show();
    m_stacked_widget->addWidget(logo);

    m_stacked_widget->show();
    m_mainWindow->setCentralWidget(m_stacked_widget);
    m_mainWindow->setWindowTitle(UI_TITLE + " [" + getConfiguration(CONF_BASE_PEERID, ADDR_GUI) + "]");
    m_mainWindow->show();
}

QImage GUIManager::renderSVGLogo(QString path, int width, int height){
    QImage img (width, height, QImage::Format_ARGB32);
    if(!path.isEmpty()){
        QSvgRenderer renderer(path);
        QPainter painter (&img);
        renderer.render(&painter);
    }
    return img;
}

double GUIManager::maxScaleFactor(int width, int height, int maxW, int maxH){
    double xFactor = maxW / width;
    double yFactor = maxH / height;
    return (xFactor <= yFactor? xFactor :yFactor);
}

void GUIManager::addPlugin(Plugin *plugin){
#ifdef QT_DEBUG
    logDebug("GUIManager", "Adding plug-in " + plugin->getId() + " to GUI");
#endif
    if(!m_widget_store.keys().contains(plugin->getId())){
        m_widget_store.insert(plugin->getId(), plugin->getWidget(m_width, m_height, m_stacked_widget));
    }
}

void GUIManager::removePlugin(QString pluginid){
#ifdef QT_DEBUG
    logDebug("GUIManager", "Removing plug-in from GUI");
#endif
    if(m_widget_store.keys().contains(pluginid)){
        if(m_currently_displayed.contains(pluginid)){
            hidePlugin(pluginid);
        }
        m_widget_store.remove(pluginid);
    }
}

//FIXME This mehtod contains an error
void GUIManager::showPlugin(QString pluginid){
    if(!pluginid.isEmpty() && m_widget_store.keys().contains(pluginid)){
        if(m_currently_displayed.contains(pluginid)){
#ifdef QT_DEBUG
        logDebug("GUIManager", "Showing plug-in: " + pluginid);
#endif
            int index = m_stacked_widget->indexOf(m_widget_store.value(pluginid));
            m_stacked_widget->setCurrentIndex(index);
            //m_stacked_widget->setCurrentWidget(m_widget_store.value(pluginid));
            m_widget_store.value(pluginid)->show();
        }else{
#ifdef QT_DEBUG
            logDebug("GUIManager", "Initial showing plug-in: " + pluginid + "(" + QString::number(m_widget_store.value(pluginid)->width()) + "x" +  QString::number(m_widget_store.value(pluginid)->height()) + ")");
#endif
            m_stacked_widget->addWidget(m_widget_store.value(pluginid));
            m_widget_store.value(pluginid)->show();
            int index = m_stacked_widget->indexOf(m_widget_store.value(pluginid));
            m_stacked_widget->setCurrentIndex(index);
            //m_stacked_widget->setCurrentWidget(m_widget_store.value(pluginid));
            m_currently_displayed.append(pluginid);
            //m_widget_store.value(pluginid)->setFocus();
        }
    }else if(!pluginid.isEmpty()){
#ifdef QT_DEBUG
        logDebug("GUIManager", "Plug-in not in widget store: " + pluginid);
#endif
    }
}

void GUIManager::hidePlugin(QString pluginid){
#ifdef QT_DEBUG
    logDebug("GUIManager", "Hiding plug-in");
#endif
    if(m_currently_displayed.contains(pluginid) && m_widget_store.keys().contains(pluginid)){
        m_widget_store.value(pluginid)->hide();
        m_stacked_widget->removeWidget(m_widget_store.value(pluginid));
        m_currently_displayed.removeAll(pluginid);
    }
}

void GUIManager::processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message){
#ifdef QT_DEBUG
    logDebug("GUIManager", message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif

    QStringList cmd = message.split(";");
    if(cmd.size() > 1 && cmd.first().compare("show", Qt::CaseInsensitive) == 0){
        for(int i = 1; i < cmd.size(); i++){
            showPlugin(cmd.at(i));
        }
    }else if(cmd.size() > 1 && cmd.first().compare("hide", Qt::CaseInsensitive) == 0){
        for(int i = 1; i < cmd.size(); i++){
            hidePlugin(cmd.at(i));
        }
    }

    if(expectingReply){
        send(senderpeer, senderplugin, ADDR_PEER_LOCAL, ADDR_GUI, id, "");
    }
}
