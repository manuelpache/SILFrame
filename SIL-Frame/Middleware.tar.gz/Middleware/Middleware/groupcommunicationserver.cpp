#include "groupcommunicationserver.h"

GroupCommunicationServer::GroupCommunicationServer(int port, QString peerid, int timeout):
    m_port(port), m_peerid(peerid), m_timeout(timeout){
}

GroupCommunicationServer::~GroupCommunicationServer(){
    if(m_server) delete m_server;
}

void GroupCommunicationServer::initialize(){
    m_server = new QTcpServer();
    QObject::connect(m_server, SIGNAL(newConnection()), this, SLOT(incoming()));

    if(!m_server->listen(QHostAddress::Any, m_port)){
        logError("GroupCommunicationServer", "Failed to setup server on port: " + QString::number(m_port));
    }else{
#ifdef QT_DEBUG
        logDebug("GroupCommunicationServer", "Server started on port: " + QString::number(m_port));
#endif
    }
}

/*
void GroupCommunicationServer::connectThread(GroupCommunicationReceiver *thread){
    connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));

    QObject::connect(thread, SIGNAL(loggingDebug(QString,QString)), this, SLOT(logDebug(QString,QString)));
    QObject::connect(thread, SIGNAL(loggingWarning(QString,QString)), this, SLOT(logWarning(QString,QString)));
    QObject::connect(thread, SIGNAL(loggingError(QString,QString)), this, SLOT(logError(QString,QString)));

    QObject::connect(thread, SIGNAL(sendMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)), this, SLOT(receiveMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)));
}
*/

void GroupCommunicationServer::incoming(){
    QTcpSocket *socket = m_server->nextPendingConnection();
    QObject::connect(socket, SIGNAL(disconnected()), socket, SLOT(deleteLater()));

#ifdef QT_DEBUG
    logDebug(SIL_GROUP_SERVER, "Incoming message from " + socket->peerAddress().toString() + ":" + QString::number(socket->peerPort()));
#endif

    QStringList message;
    bool success = readIncomingMessage(socket, &message);
    closeConnection(socket);

    if(success){
        if(message.first().compare(ADDR_PEER_LOCAL, Qt::CaseInsensitive) != 0){
#ifdef QT_DEBUG
            logDebug(SIL_GROUP_SERVER, "RELAY MESSAGE");
#endif
            return;
        } else {
            send(message[0], message[1], message[2], message[3], QDateTime::fromString(message[4], Qt::ISODate), message[5], message[6].compare(BASE_TRUE, Qt::CaseInsensitive) == 0, message[7]);
        }
    }else{
        logError(SIL_GROUP_SERVER, "Failed to read message");
    }

/*
    GroupCommunicationReceiver *thread = new GroupCommunicationReceiver(socket, m_peerid, m_timeout);
    socket->moveToThread(thread);
    QObject::connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));
    connectThread(thread);
    //thread->run();
    thread->start();
*/

}

void GroupCommunicationServer::processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message){
#ifdef QT_DEBUG
    logDebug("GroupCommunicationServer", message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif
    send(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);
}


//#################################################################################################################
//# methods handling actual network communication
//#################################################################################################################

void GroupCommunicationServer::closeConnection(QTcpSocket* socket){
#ifdef QT_DEBUG
        logDebug(SIL_GROUP_IN, "Closing connection to " + socket->peerName() + ":" + QString::number(socket->peerPort()));
#endif
  if(socket->state() == QTcpSocket::ConnectedState){
    socket->close();
    socket->disconnectFromHost();
    if(socket->state()==QTcpSocket::ConnectedState){
        logError(SIL_GROUP_IN, "Failed to close connection");
    }
  }
}

bool GroupCommunicationServer::readIncomingMessage(QTcpSocket *socket, QStringList *msg){
    if(isValidConnection(socket)){
        foreach(QString msgpart, QString(readIncomingData(socket)).split(";")){
            msg->append(msgpart);
        }
        if(isValidHeader(msg)){
  #ifdef QT_DEBUG
            logDebug(SIL_GROUP_IN, "Reading message: " + msg->join(";"));
  #endif
          if(msg->at(0).split(":").first() == m_peerid){
            msg->replace(0, ADDR_PEER_LOCAL);
            msg->replace(2, msg->at(2).split(":").first());
          }
          if(msg->at(3).split(":").first() == m_peerid){
              msg->replace(3, ADDR_PEER_LOCAL);
          }
          msg->append(QString(readIncomingData(socket)));
          return true;
        }
    }
    return false;
}

bool GroupCommunicationServer::isValidConnection(const QTcpSocket *socket){
    return (socket && socket->isValid() && socket->isOpen());
}

bool GroupCommunicationServer::isValidHeader(const QStringList *header){
    return (header && !header->isEmpty() && header->size() == 7);
}

QByteArray GroupCommunicationServer::readIncomingData(QTcpSocket *socket){
    // read blocksize(s)
    QByteArray data;
    if(socket && socket->state() == QTcpSocket::ConnectedState){
      while (socket->bytesAvailable() < (int) sizeof(quint32)) {
        if (!socket->waitForReadyRead(m_timeout)) {
          return QByteArray();
        }
      }

      QDataStream in(socket);
      in.setVersion(QDataStream::Qt_4_8);

      int blocksize;
      in >> blocksize;

      // read data
      while (socket->bytesAvailable() < blocksize){
        if (!socket->waitForReadyRead(m_timeout)) {
          return QByteArray();
        }
      }

      in >> data;
    }
    return data;
}
