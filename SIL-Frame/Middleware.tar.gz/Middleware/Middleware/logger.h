#ifndef LOGGER_H
#define LOGGER_H

#include "middleware.h"

#include <QRegExp>
#include <QDebug>

class Logger: public Middleware {
    Q_OBJECT

public:
    Logger();
    virtual ~Logger();

    void initialize();

    /*!
     * \brief setLogFilter
     * \param pattern
     */
    void setLogFilter(QString pattern);
    /*!
     * \brief setLogLevel
     * \param level
     */
    void setLogLevel(QString level);
    /*!
     * \brief setLogPrefix
     * \param prefix
     */
    void setLogPrefix(QString prefix);

public slots:
    /*!
     * \brief logDebugMessage
     * \param sender
     * \param message
     */
    void logDebugMessage(QString sender, QString message);
    /*!
     * \brief logWarningMessage
     * \param sender
     * \param message
     */
    void logWarningMessage(QString sender, QString message);
    /*!
     * \brief logErrorMessage
     * \param sender
     * \param message
     */
    void logErrorMessage(QString sender, QString message);

protected:
    void processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);


private:
    QRegExp *m_logfilter;
    QString m_prefix;
};

#endif // LOGGER_H
