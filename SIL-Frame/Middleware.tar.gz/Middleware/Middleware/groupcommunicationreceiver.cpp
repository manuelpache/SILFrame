#include "groupcommunicationreceiver.h"

GroupCommunicationReceiver::GroupCommunicationReceiver(QTcpSocket *socket, QString peerid, int timeout):
    m_socket(socket), m_peerid(peerid), m_timeout(timeout){
}

GroupCommunicationReceiver::~GroupCommunicationReceiver(){
    if(m_socket) delete m_socket;
}

//#################################################################################################################
//# gluing everything together
//#################################################################################################################

void GroupCommunicationReceiver::run(){
    QStringList message;
    bool success = readIncomingMessage(m_socket, &message);
    closeConnection(m_socket);

    if(success){
        if(message.first() != ADDR_PEER_LOCAL){
            return; //ToDo terminate thread
        } else {
            emit sendMessage(message[0], message[1], message[2], message[3], QDateTime::fromString(message[4], Qt::ISODate), message[5], message[6].compare(BASE_TRUE, Qt::CaseInsensitive) == 0, message[7]);
        }
    }
}

//#################################################################################################################
//# methods handling actual network communication
//#################################################################################################################

void GroupCommunicationReceiver::closeConnection(QTcpSocket* socket){
#ifdef QT_DEBUG
        logDebug(SIL_GROUP_IN, "Closing connection to " + socket->peerName() + ":" + QString::number(socket->peerPort()));
#endif
  if(socket->state() == QTcpSocket::ConnectedState){
    socket->disconnectFromHost();
    if(socket->state()==QTcpSocket::ConnectedState){
        logError(SIL_GROUP_IN, "Failed to close connection");
    }
  }
}

bool GroupCommunicationReceiver::readIncomingMessage(QTcpSocket *socket, QStringList *msg){
    if(isValidConnection(socket)){
        foreach(QString msgpart, QString(readIncomingData(socket)).split(";")){
            msg->append(msgpart);
        }
        if(isValidHeader(msg)){
  #ifdef QT_DEBUG
            logDebug(SIL_GROUP_IN, "Reading message: " + msg->join(";"));
  #endif
          if(msg->at(0).split(":").first() == m_peerid){
            msg->replace(0, ADDR_PEER_LOCAL);
            msg->replace(2, msg->at(2).split(":").first());
          }
          if(msg->at(3).split(":").first() == m_peerid){
              msg->replace(3, ADDR_PEER_LOCAL);
          }
          msg->append(QString(readIncomingData(socket)));
          return true;
        }
    }
    return false;
}

bool GroupCommunicationReceiver::isValidConnection(const QTcpSocket *socket){
    return (socket && socket->isValid() && socket->isOpen());
}

bool GroupCommunicationReceiver::isValidHeader(const QStringList *header){
    return (header && !header->isEmpty() && header->size() == 7);
}

QByteArray GroupCommunicationReceiver::readIncomingData(QTcpSocket *socket){
    // read blocksize(s)
    QByteArray data;
    if(socket && socket->state() == QTcpSocket::ConnectedState){
      while (socket->bytesAvailable() < (int) sizeof(quint32)) {
        if (!socket->waitForReadyRead(m_timeout)) {
          return QByteArray();
        }
      }

      QDataStream in(socket);
      in.setVersion(QDataStream::Qt_4_8);

      int blocksize;
      in >> blocksize;

      // read data
      while (socket->bytesAvailable() < blocksize){
        if (!socket->waitForReadyRead(m_timeout)) {
          return QByteArray();
        }
      }

      in >> data;
    }
    return data;
}
