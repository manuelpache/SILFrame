#include "localcommunicationmanager.h"

LocalCommunicationManager::LocalCommunicationManager(): m_announcement(new AnnouncementManager){
    QObject::connect(m_announcement, SIGNAL(send(QString,QString,QString,QString,QDateTime,QString,bool,QString)), this, SLOT(receiveMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)));
}

LocalCommunicationManager::~LocalCommunicationManager(){
    if(m_announcement) delete m_announcement;
}

void LocalCommunicationManager::initialize(){}

void LocalCommunicationManager::processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message){
#ifdef QT_DEBUG
    logDebug(SIL_LOCAL, message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif

    if(receiverpeer.compare(ADDR_PEER_LOCAL, Qt::CaseInsensitive) != 0){
        emit sendToGroupCommunicationSender(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);

    }else if(receiverplugin.compare(ADDR_MIDDLEWARE, Qt::CaseInsensitive) == 0){
        middlewareCMD(message);
        if(expectingReply)
            processMessage(senderpeer, senderplugin, receiverpeer, receiverplugin, QDateTime::currentDateTime(), id, false, "");

    }else if(receiverplugin.compare(ADDR_SUBSCRIBE, Qt::CaseInsensitive) == 0){
        m_announcement->subscribe(senderpeer, senderplugin, message);

    }else if(receiverplugin.compare(ADDR_UNSUBSCRIBE, Qt::CaseInsensitive) == 0){
        m_announcement->unsubscribe(senderpeer, senderplugin, message);

    }else if(receiverplugin.compare(ADDR_ANNOUNCEMENT, Qt::CaseInsensitive) == 0){
        m_announcement->announce(id, senderpeer, senderplugin, timestamp, id, message);

    }else if(receiverplugin.compare(ADDR_GUI, Qt::CaseInsensitive) == 0){
        emit sendToGUI(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);

    }else if(receiverplugin.compare(ADDR_CONFIGURATION, Qt::CaseInsensitive) == 0){
        emit sendToConfiguration(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);

    }else if(receiverplugin.compare(ADDR_PEERMANAGER, Qt::CaseInsensitive) == 0){
        emit sendToPeerManager(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);

    }else if(receiverplugin.compare(ADDR_PLUGINMANAGER, Qt::CaseInsensitive) == 0){
        emit sendToPluginManager(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);

    }else if(receiverplugin.compare(ADDR_GROUP_IN, Qt::CaseInsensitive) == 0){
        emit sendToGroupCommunicationReceiver(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);

    }else if(receiverplugin.compare(ADDR_GROUP_OUT, Qt::CaseInsensitive) == 0){
        emit sendToGroupCommunicationSender(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);

    }else{
        emit sendToPlugin(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);
    }
}

void LocalCommunicationManager::middlewareCMD(QString cmd){
    if(cmd.compare(SIL_CMD_SHUTDOWN, Qt::CaseInsensitive) == 0){
        emit cmdShutdown();
    }
}
