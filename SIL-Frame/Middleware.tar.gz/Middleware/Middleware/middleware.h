#ifndef MIDDLEWARE_H
#define MIDDLEWARE_H

#include "../Plugin_Interface/sil_constants.h"
#include "../Plugin_Interface/plugin.h"

#include <QObject>
#include <QThread>
#include <QString>
#include <QDateTime>
#include <QMap>
#include <QPair>
#include <QSemaphore>
#include <QUuid>

class Middleware: public QThread{
    Q_OBJECT

signals:
    /*!
     * \brief Signal emitted when a plug-in executes a logging command for debug
     * \param sender of the log message
     * \param message to be logged
     */
    void loggingDebug(QString sender, QString message);
    /*!
     * \brief Signal emitted when a plug-in executes a logging command for warning
     * \param sender of the log message
     * \param message to be logged
     */
    void loggingWarning(QString sender, QString message);
    /*!
     * \brief Signal emitted when a plug-in executes a logging command for error
     * \param sender of the log message
     * \param message to be logged
     */
    void loggingError(QString sender, QString message);
    /*!
     * \brief Signal emitted to send a message
     * \param receiverpeer id of the receiving peer
     * \param receiverplugin id of the receiving plug-in
     * \param senderpeer id of the peer the message was send from
     * \param senderplugin id of the plug-in that send the message
     * \param timestamp when the message was send
     * \param id identify of the message
     * \param expectingReply
     * \param message contains the actual message
     */
    void sendMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

public:
    Middleware();
    virtual ~Middleware();

    /*!
     * \brief initializes the part of the middleware system
     */
    virtual void initialize(){;}

    virtual void run(){;}

    /*!
     * \brief Provides the identifier of the SIL version
     * \return identifier of the SIL version
     */
    QString getVersion();

public slots:
    /*!
     * \brief Provides the incoming point for messages
     * \param receiverpeer id of the receiving peer
     * \param receiverplugin id of the receiving plug-in
     * \param senderpeer id of the peer the message was send from
     * \param senderplugin id of the plug-in that send the message
     * \param timestamp when the message was send
     * \param id identify of the message
     * \param expectingReply indicates if the message required a response
     * \param message contains the actual message
     */
    void receiveMessage(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectingReply, const QString message);

protected slots:
    /*!
     * \brief Shorthand for emitting a log message for debug
     * \param sender of the log message
     * \param message to be logged
     */
    void logDebug(QString sender, QString message);
    /*!
     * \brief Shorthand for emitting a log message for warning
     * \param sender of the log message
     * \param message to be logged
     */
    void logWarning(QString sender, QString message);
    /*!
     * \brief Shorthand for emitting a log message for error
     * \param sender of the log message
     * \param message to be logged
     */
    void logError(QString sender, QString message);

protected:
   /*!
    * \brief send
    * \param receiverpeer id of the receiving peer
    * \param receiverplugin id of the receiving plug-in
    * \param senderpeer id of the peer the message was send from
    * \param senderplugin id of the plug-in that send the message
    * \param id identify of the message
    * \param expectingReply indicates if the message required a response
    * \param message contains the actual message
    */
    void send(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QString id, const QString message);
    void send(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QString id, const bool expectinReply, const QString message);
    void send(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QDateTime time, const QString id, const bool expectinReply, const QString message);

    /*!
     * \brief syncSend
     * \param receiverpeer id of the receiving peer
     * \param receiverplugin id of the receiving plug-in
     * \param senderpeer id of the peer the message was send from
     * \param senderplugin id of the plug-in that send the message
     * \param message contains the actual message
     * \return response
     */
    QString syncSend(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QString message);

    /*!
     * \brief getConfiguration
     * \param key
     * \param sender
     * \return
     */
    QString getConfiguration(QString key, QString sender);

    /*!
     * \brief Processes an incoming message on individal basis
     * \param receiverpeer id of the receiving peer
     * \param receiverplugin id of the receiving plug-in
     * \param senderpeer id of the peer the message was send from
     * \param senderplugin id of the plug-in that send the message
     * \param timestamp when the message was send
     * \param id identify of the message
     * \param expectingReply indicates if the message required a response
     * \param message contains the actual message
     */
    virtual void processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

    /*!
     * \brief message2str
     * \param receiverpeer id of the receiving peer
     * \param receiverplugin id of the receiving plug-in
     * \param senderpeer id of the peer the message was send from
     * \param senderplugin id of the plug-in that send the message
     * \param timestamp when the message was send
     * \param id identify of the message
     * \param expectingReply indicates if the message required a response
     * \param message contains the actual message
     * \return a single QString describing the message
     */
    QString message2str(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectingReply, const QString message);

private:
    QMap<QString, QPair<QSemaphore*, QString> > *m_currentSynchronousMessages; /*!< list of open messages for with a reply is required */
};

#endif // MIDDLEWARE_H
