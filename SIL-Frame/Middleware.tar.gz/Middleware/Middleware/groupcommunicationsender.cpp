#include "groupcommunicationsender.h"

GroupCommunicationSender::GroupCommunicationSender(){
}

GroupCommunicationSender::~GroupCommunicationSender(){
}

void GroupCommunicationSender::initialize(){
    m_peerid = getConfiguration(CONF_BASE_PEERID, ADDR_GROUP_OUT);
    m_timeout = TIMEOUT;
}

QString GroupCommunicationSender::requestPeer(QString peerid){
    return syncSend(ADDR_PEER_LOCAL, ADDR_PEERMANAGER, ADDR_PEER_LOCAL, ADDR_GROUP_OUT, "get;" + peerid);
}

void GroupCommunicationSender::processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message){
    if(receiverpeer.compare(ADDR_PEER_LOCAL, Qt::CaseInsensitive) == 0){
#ifdef QT_DEBUG
    logDebug(SIL_GROUP_OUT, "Local message relay: " + message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif
        //ToDo act on local messages
    }else{
#ifdef QT_DEBUG
    logDebug(SIL_GROUP_OUT, "Sending to remote: " + message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif
        //send to remote peer
        QTcpSocket *socket = new QTcpSocket();
        if(!transmitMessage(socket, receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message)){
           logError(SIL_GROUP_OUT, "SENDING FAILED: " + message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
        }
        closeConnection(socket);
        if(socket) delete socket;
    }
}

//#################################################################################################################
//# methods handling actual network communication
//#################################################################################################################

bool GroupCommunicationSender::transmitMessage(QTcpSocket *socket, const QString peer, const QString plugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectReply, QString message){
    QList<QByteArray> datalist;
    datalist.append(message.toUtf8());
    QStringList header;
    if(generateHeader(&header,peer, plugin, senderpeer, senderplugin,timestamp, id, expectReply)){
        if(header.size() >= 1){
          QStringList address = header.first().split(":", QString::SkipEmptyParts);
          if(address.size() == 3){
            openConnection(socket, address.at(1), address.at(2).toInt());
            return transmit(socket, &header, &datalist);
          }else{
              logWarning(SIL_GROUP_OUT, "Unknown address: " + address.join(";"));
              return false;
          }
        }else{
            return false;
        }
    }else{
        return false;
    }
}

bool GroupCommunicationSender::transmit(QTcpSocket *socket, const QStringList *header, const QList<QByteArray> *data){
  if(isValidHeader(header)){
    // send message header
    QByteArray headerdata = header->join(";").toUtf8();
    transmitData(socket, headerdata);

    // send message body
    for(int i = 0; i < data->size(); i++){
      transmitData(socket, data->at(i));
    }
    // the flush creates a problem.
    //socket->flush();

#ifdef QT_DEBUG
    logDebug(SIL_GROUP_OUT, "Transmission finished");
#endif
    return true;
  }
  logError(SIL_GROUP_OUT, "Transmission failed");
  return false;
}

void GroupCommunicationSender::transmitData(QTcpSocket *socket, QByteArray data){
  if(socket && socket->isOpen() && socket->state() == QAbstractSocket::ConnectedState){
    QByteArray block;
    QDataStream stream (&block, QIODevice::WriteOnly);
    stream.setVersion(QDataStream::Qt_4_8);
    stream << (quint32) 0;
    stream << data.data();
    stream.device()->seek(0);
    stream << (quint32)(block.size() - sizeof(quint32));

    int transmitted = 0;
    while(transmitted < block.size()){
      transmitted += socket->write(block);
    }
  }
}

bool GroupCommunicationSender::generateHeader(QStringList *header, const QString peer, const QString plugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectReply){
    //header = new QStringList;
    QRegExp nameAddressIPv4Pattern(NETWORK_IPV4);
    //QRegExp nameAddressIPv6Pattern(STR_NETWORK_IPV6);
    if(nameAddressIPv4Pattern.exactMatch(peer)){// || nameAddressIPv6Pattern.exactMatch(peer)){
        header->append(peer);
    } else { // resolve peer short hand to complete peeraddress
          QStringList peers = requestPeer(peer).split(";", QString::SkipEmptyParts);
          if(!peers.isEmpty() && !peers.first().isEmpty()){
              header->append(peers.first());
          } else {
              return false;
          }
    }
    header->append(plugin);
    if(senderpeer.compare(ADDR_PEER_LOCAL) == 0){
        header->append(m_peerid);
    } else{
      header->append(senderpeer);
    }
    header->append(senderplugin);
    header->append(timestamp.toString(Qt::ISODate));
    header->append(id);
    header->append((expectReply ? BASE_TRUE : BASE_FALSE));

    return isValidHeader(header);
}

void GroupCommunicationSender::openConnection(QTcpSocket *socket, QString address, int port){
  socket->abort();
  socket->connectToHost(address, port);
  if(!socket->waitForConnected(m_timeout)){
      logError(SIL_GROUP_OUT, "Connection to: " + address + " " + QString::number(port) + " TIMEOUTED");
  }else{
      if(socket->isOpen() && socket->state() == QTcpSocket::ConnectedState){
#ifdef QT_DEBUG
        logDebug(SIL_GROUP_OUT, "Connection to: " + address + " " + QString::number(port) + " established");
#endif
      }else{
        logError(SIL_GROUP_OUT, "Connection to: " + address + " " + QString::number(port) + " FAILED");
      }
  }
}

void GroupCommunicationSender::closeConnection(QTcpSocket* socket){
    if(socket->state() == QTcpSocket::ConnectedState){
#ifdef QT_DEBUG
    logDebug(SIL_GROUP_OUT, "Waiting for connection " + socket->peerName() + ":" + QString::number(socket->peerPort()) + " to be closed for " + QString::number(m_timeout));
#endif
        socket->close();
        socket->waitForDisconnected(m_timeout);
        if(socket->state()==QTcpSocket::ConnectedState){
            logError(SIL_GROUP_OUT, "Closing connection failed.");
        }else{
#ifdef QT_DEBUG
            logDebug(SIL_GROUP_OUT, "Connection was closed.");
#endif
        }
    }
}

bool GroupCommunicationSender::isValidHeader(const QStringList *header){
  return (header && !header->isEmpty() && header->size() == 7);
}

bool GroupCommunicationSender::isValidConnection(const QTcpSocket *socket){
  return (socket && socket->isValid() && socket->isOpen());
}
