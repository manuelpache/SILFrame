#include "announcementmanager.h"

AnnouncementManager::AnnouncementManager(): m_subscriptions(){
}

AnnouncementManager::~AnnouncementManager(){
}

void AnnouncementManager::subscribe(QString peer, QString plugin, QString topic){
    if(!m_subscriptions.keys().contains(topic)){
        m_subscriptions.insert(topic, new QList<QPair<QString, QString> > ());
    }
    QPair<QString, QString> subscriber = qMakePair(peer, plugin);
    if(!m_subscriptions.value(topic)->contains(subscriber)){
        m_subscriptions.value(topic)->append(subscriber);
    }
}

void AnnouncementManager::unsubscribe(QString peer, QString plugin, QString topic){
    if(m_subscriptions.keys().contains(topic)){
        for(int i = 0; i < m_subscriptions.value(topic)->size(); i++){
            QPair<QString, QString> subscriber = m_subscriptions.value(topic)->at(i);
            if(subscriber.first.compare(peer) == 0 && subscriber.second.compare(plugin) == 0){
                m_subscriptions.value(topic)->removeAt(i);
                break;
            }
        }
        if(m_subscriptions.value(topic)->isEmpty()){
            m_subscriptions.remove(topic);
        }
    }
}

// Remember topic == id
void AnnouncementManager::announce(QString topic, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, QString message){
    if(m_subscriptions.keys().contains(topic)){;
        for(int i = 0; i < m_subscriptions.value(topic)->size(); i++){
            QPair<QString, QString> subscriber = m_subscriptions.value(topic)->at(i);
            emit send(subscriber.first, subscriber.second, senderpeer,senderplugin, timestamp, id, false, message);
        }
    }
}
