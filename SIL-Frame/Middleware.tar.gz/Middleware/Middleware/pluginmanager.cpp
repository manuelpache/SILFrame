#include "pluginmanager.h"

PluginManager::PluginManager(system_mode_t mode, GUIManager *gui): m_mode(mode), m_gui(gui){
}

PluginManager::~PluginManager(){
}

void PluginManager::initialize(){
    m_restrictions = getConfiguration(CONF_PLUGIN_RESTRICTIONS, ADDR_PLUGINMANAGER).split(";", QString::SkipEmptyParts);
}

void PluginManager::autostart(){
    foreach (QString id, m_autostartPlugins) {
        if(m_plugins.value(id)->getPluginStatus() == AVAILABLE){
            m_plugins.value(id)->setupPlugin(m_mode);
        }
        if(m_plugins.value(id)->getPluginStatus() == INITIALIZED){
            m_plugins.value(id)->activatePlugin();
        }
        if(m_plugins.value(id)->getPluginStatus() == ACTIVE && m_plugins.value(id)->hasGUI()){
                send(ADDR_PEER_LOCAL, ADDR_GUI, ADDR_PEER_LOCAL, ADDR_PLUGINMANAGER, "autostart gui plug-in", "show;" + id);
        }
        if(!m_plugins.value(id)->getPluginStatus() == ACTIVE){
            logWarning(SIL_PLUGINS, "Could not automatically start plug-in: " + id);
        }
    }
}

void PluginManager::shutdown(){
    foreach (QString id, m_plugins.keys()) {
        m_plugins.value(id)->shutdownPlugin();
    }
}

void PluginManager::detectPlugins(){
    QString pluginPath = getConfiguration(CONF_BASE_PLUGIN_PATH, ADDR_PLUGINMANAGER);
    if(!pluginPath.isEmpty()){
        QDir path (pluginPath);
        QStringList files = path.entryList(QDir::Files);
        // try and load all available plug-ins
        foreach(QString file, files){
            Plugin *plugin = loadPlugin(path.absoluteFilePath(file));
            if(plugin && isCompatable(plugin)){
                m_all_possible_plugins.append(plugin->getId() + ":" + file);
                if(isAllowed(file, plugin)){
                    m_pluginFiles.insert(plugin->getId(), path.absoluteFilePath(file));
                    m_plugins.insert(plugin->getId(), plugin);
                }else{
#ifdef QT_DEBUG
                    logDebug(SIL_PLUGINS, "Plug-in " + file + " is not allowed");
#endif
                }
            }else{
#ifdef QT_DEBUG
                    logDebug(SIL_PLUGINS, "File " + file + " provides no plug-in");
#endif
            }
        }

        // check dependencies
        QStringList plugins = m_plugins.keys();
        while(!plugins.isEmpty()){
            QString id = plugins.takeFirst();
            if(!checkDependencies(m_plugins.value(id))){
                m_plugins.remove(id);
                plugins = m_plugins.keys();
#ifdef QT_DEBUG
                    logDebug(SIL_PLUGINS, "Plug-in " + id + " failed dependencies check");
#endif
            }
        }

        // setup plug-ins
        foreach(QString id, m_plugins.keys()){
            setupPlugin(m_plugins.value(id));
        }
#ifdef QT_DEBUG
        logDebug(SIL_PLUGINS, "Detected " + QString::number(m_plugins.keys().size()) + " plug-ins");
#endif
    }else{
        logError(SIL_PLUGINS, "No plug-in folder provided");
    }
}

void PluginManager::setupPlugin(Plugin *plugin){
    if(plugin){
        //setup connections
        QObject::connect(plugin, SIGNAL(loggingDebug(QString,QString)), this, SLOT(logDebug(QString,QString)));
        QObject::connect(plugin, SIGNAL(loggingWarning(QString,QString)), this, SLOT(logWarning(QString,QString)));
        QObject::connect(plugin, SIGNAL(loggingError(QString,QString)), this, SLOT(logError(QString,QString)));
        QObject::connect(plugin, SIGNAL(sendMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)), this, SLOT(processPluginMessage(QString,QString,QString,QString,QDateTime,QString,bool,QString)));

        // check autostart
        if(plugin->shouldAutostart()){
            m_autostartPlugins.append(plugin->getId());
        }

        // setup GUI
        if(plugin->hasGUI()){
            m_gui->addPlugin(plugin);
        }

    #ifdef QT_DEBUG
            logDebug(SIL_PLUGINS, "Plug-in " + plugin->getId() + " has been successfully setup");
    #endif
    }
}

Plugin* PluginManager::loadPlugin(QString file){
    try{
        QPluginLoader loader(file, this);
        QObject *couldBePlugin = loader.instance();
        if(couldBePlugin){
            return qobject_cast<Plugin*>(couldBePlugin);
        }
        return 0;
    }catch(...){
        logError(SIL_PLUGINS, "FAILED LOADING PLUGIN: " + file);
        return 0;
    }
}

bool PluginManager::reloadPlugin(QString id){
    //ToDo everything
    return false;
}

void PluginManager::setupPlugin(QString id){
#ifdef QT_DEBUG
    logDebug(SIL_PLUGINS, "Trying to setup plug-in: " + id);
#endif
    if(!id.isEmpty() && m_plugins.keys().contains(id) && (m_plugins.value(id)->getPluginStatus() == AVAILABLE || m_plugins.value(id)->getPluginStatus() == INITIALIZED)){
        if(!(m_plugins.keys().contains(id) && m_plugins.value(id)->setupPlugin(m_mode))){
            logWarning(SIL_PLUGINS, "Failed to setup plug-in: " + id);
        }
    }
}

void PluginManager::shutdownPlugin(QString id){
#ifdef QT_DEBUG
    logDebug(SIL_PLUGINS, "Trying to shutdown plug-in: " + id);
#endif
    if(id.isEmpty() || !(m_plugins.keys().contains(id) && m_plugins.value(id)->shutdownPlugin())){
        logWarning(SIL_PLUGINS, "Failed to shutdown plug-in: " + id);
    }
}

void PluginManager::startPlugin(QString id){
#ifdef QT_DEBUG
    logDebug(SIL_PLUGINS, "Trying to start plug-in: " + id);
#endif
    if(!id.isEmpty() && m_plugins.keys().contains(id)){
        if(m_plugins.value(id)->getPluginStatus() == AVAILABLE || m_plugins.value(id)->getPluginStatus() == INITIALIZED){
            setupPlugin(id);
        }
        if(!m_plugins.value(id)->activatePlugin()){
            logWarning(SIL_PLUGINS, "Failed to start plug-in: " + id);
            return;
        }
        //Start plugin thread
        QThread t;
        //Prepare execution of plugin main loop
        QTimer::singleShot(500, m_plugins.value(id), SLOT(mainloop()));
        m_plugins.value(id)->moveToThread(&t);
        t.start();
        m_pluginThreads.insert(id, &t);

        //Execute plugin main loop
        //m_plugins.value(id)->run();
    }


    if(id.isEmpty() || !(m_plugins.keys().contains(id) && m_plugins.value(id)->activatePlugin())){
        logWarning(SIL_PLUGINS, "Failed to start plug-in: " + id);
    }
}

void PluginManager::stopPlugin(QString id){
#ifdef QT_DEBUG
    logDebug(SIL_PLUGINS, "Trying to stop plug-in: " + id);
#endif
    if(!id.isEmpty() && m_plugins.keys().contains(id) && m_plugins.value(id)->getPluginStatus() == ACTIVE){
        if(!m_plugins.value(id)->stopPlugin()){
            logWarning(SIL_PLUGINS, "Failed to stop plug-in: " + id);
        }
        //Stop plugin thread
        if(m_pluginThreads.keys().contains(id)){
            QThread *t = m_pluginThreads.value(id);
            t->quit();
            m_pluginThreads.remove(id);
            delete t;
        }
    }
}

bool PluginManager::isAllowed(QString file, Plugin *plugin){
    if(m_restrictions.isEmpty()) return true;
    if((m_restrictions.first().compare("-") != 0)){
        return m_restrictions.contains(file);
    }else{
        return !m_restrictions.contains(file);
    }
}

bool PluginManager::isCompatable(Plugin *plugin){
    bool compatable = plugin->getQtVersion().compare(QString(QT_VERSION_STR)) == 0;
    if(!compatable)
        logWarning(SIL_PLUGINS, "Incompatable Qt versions. Requiring " + QString(QT_VERSION_STR));
    return compatable;
}

bool PluginManager::checkDependencies(Plugin *plugin){
    foreach(QString dependency, plugin->dependentPlugins()){
        if(!m_plugins.keys().contains(dependency)){
#ifdef QT_DEBUG
            logDebug(SIL_PLUGINS, "Missing dependency: " + dependency);
#endif
            return false;
        }
    }
    return true;
}

void PluginManager::processPluginMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message){
    if(receiverpeer.compare(ADDR_PEER_LOCAL, Qt::CaseInsensitive) == 0 && !receiverplugin.contains(ADDR_MIDDLEWARE)){
        relayToPlugin(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);
    }else{
        send(receiverpeer,receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);
    }
}

void PluginManager::processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message){
#ifdef QT_DEBUG
    logDebug(SIL_PLUGINS, message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif
    if(receiverpeer.compare(ADDR_PEER_LOCAL, Qt::CaseInsensitive) == 0){
        if(receiverplugin.compare(ADDR_PLUGINMANAGER, Qt::CaseInsensitive) == 0){
            // handling incomming messages destinated for PluginManager
            QStringList msg = message.split(";", QString::SkipEmptyParts);
            if(msg.size() >= 1 && (msg.first().compare("available", Qt::CaseInsensitive) == 0 || msg.first().compare("get", Qt::CaseInsensitive) == 0)){
                if(msg.size() == 1){
                    QString result = "";
                    foreach(QString peerid, m_plugins.keys()){
                        result += peerid + ";";
                    }
                    send(senderpeer, senderplugin, ADDR_PEER_LOCAL, ADDR_PLUGINMANAGER, id, result);
                }else{
                    bool available = true;
                    for(int i = 1; i < msg.size(); i++){
                        available = available && m_plugins.keys().contains(msg.at(i));
                    }
                    if(available){
                        send(senderpeer, senderplugin, ADDR_PEER_LOCAL, ADDR_PLUGINMANAGER, id, "true");
                    }else{
                        send(senderpeer, senderplugin, ADDR_PEER_LOCAL, ADDR_PLUGINMANAGER, id, "false");
                    }
                }
            }else if(msg.size() >= 1 && msg.first().compare("all", Qt::CaseInsensitive) == 0){
                // send a list of all plugins, even the restricted ones
                send(senderpeer, senderplugin, ADDR_PEER_LOCAL, ADDR_PLUGINMANAGER, id, m_all_possible_plugins.join(";"));
            }else if(msg.size() > 1 && msg.first().compare("setup", Qt::CaseInsensitive) == 0){
                for(int i = 1; i < msg.size(); i++){
                    setupPlugin(msg.at(i));
                }
            }else if(msg.size() > 1 && msg.first().compare("start", Qt::CaseInsensitive) == 0){
                for(int i = 1; i < msg.size(); i++){
                    startPlugin(msg.at(i));
                }
            }else if(msg.size() > 1 && msg.first().compare("stop", Qt::CaseInsensitive) == 0){
                for(int i = 1; i < msg.size(); i++){
                    stopPlugin(msg.at(i));
                }
            }else if(msg.size() == 1 && msg.first().compare("shutdown", Qt::CaseInsensitive) == 0){
                shutdown();
            }else if(msg.size() > 1 && msg.first().compare("shutdown", Qt::CaseInsensitive) == 0){
                for(int i = 1; i < msg.size(); i++){
                    shutdownPlugin(msg.at(i));
                }
            }
        }else{
            relayToPlugin(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);
        }
    }
}

void PluginManager::relayToPlugin(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message){
#ifdef QT_DEBUG
    logDebug(SIL_PLUGINS, "PLUGIN MSG RELAY: " + message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif
    // Relay to plug-in
    if(m_plugins.keys().contains(receiverplugin)){
        if(m_plugins.value(receiverplugin)->getPluginStatus() == AVAILABLE){
#ifdef QT_DEBUG
logDebug(SIL_PLUGINS, "Require  setup: " + receiverplugin);
#endif
            m_plugins.value(receiverplugin)->setupPlugin(m_mode);
        }

        if(m_plugins.value(receiverplugin)->getPluginStatus() == INITIALIZING){ // && senderpeer.compare(ADDR_PEER_LOCAL, Qt::CaseInsensitive) == 0){
#ifdef QT_DEBUG
logDebug(SIL_PLUGINS, "Setup message for plug-in: " + receiverplugin);
#endif
            m_plugins.value(receiverplugin)->receiveMessage(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);
        }

        if(m_plugins.value(receiverplugin)->getPluginStatus() == INITIALIZED){
#ifdef QT_DEBUG
logDebug(SIL_PLUGINS, "Require  start: " + receiverplugin);
#endif
            m_plugins.value(receiverplugin)->activatePlugin();
        }

        if(m_plugins.value(receiverplugin)->getPluginStatus() == ACTIVE || m_plugins.value(receiverplugin)->getPluginStatus() == STOPPED || m_plugins.value(receiverplugin)->getPluginStatus() == INITIALIZING){
            //FIXME better to do this via signal/slot system...
#ifdef QT_DEBUG
logDebug(SIL_PLUGINS, "RELAY " + message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif
            m_plugins.value(receiverplugin)->receiveMessage(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);
        }else if(m_plugins.value(receiverplugin)->getPluginStatus() == DEACTIVATED){
            logError(SIL_PLUGINS, "RELAY TO DEACTIVATED PLUGIN: " +message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
        }
    }else{
        logWarning(SIL_PLUGINS, "RELAY PROBLEM => " + message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
        if(expectingReply){
            send(senderpeer, senderplugin, ADDR_PEER_LOCAL, ADDR_PLUGINMANAGER, id, message);
        }
    }
}
