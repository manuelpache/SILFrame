#include "logger.h"

Logger::Logger(): m_logfilter(0), m_prefix(""){
}

Logger::~Logger()
{
    delete m_logfilter;
}

void Logger::initialize(){}

void Logger::logDebugMessage(QString sender, QString message){
  QString logmsg = "<";
  if(!m_prefix.isEmpty()){
      logmsg += m_prefix + " => ";
  }
  logmsg += "Debug " + QDateTime::currentDateTime().toString(Qt::ISODate) + "> " + sender + " -> " + message;
  if(!m_logfilter || (m_logfilter && m_logfilter->exactMatch(logmsg))){
    qDebug() << logmsg;
  }
}

void Logger::logWarningMessage(QString sender, QString message){
  QString logmsg = "<";
  if(!m_prefix.isEmpty()){
      logmsg += m_prefix + " => ";
  }
  logmsg += "Warning " + QDateTime::currentDateTime().toString(Qt::ISODate) + "> " + sender + " -> " + message;
  if(!m_logfilter || (m_logfilter && m_logfilter->exactMatch(logmsg))){
    qWarning() << logmsg;
  }
}

void Logger::logErrorMessage(QString sender, QString message){
  QString logmsg = "<";
  if(!m_prefix.isEmpty()){
      logmsg += m_prefix + " => ";
  }
  logmsg += "Error " + QDateTime::currentDateTime().toString(Qt::ISODate) + "> " + sender + " -> " + message;
  if(!m_logfilter || (m_logfilter && m_logfilter->exactMatch(logmsg))){
    qCritical() << logmsg;
  }
}

void Logger::processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message){
#ifdef QT_DEBUG
    logDebugMessage("Logger", message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif
}


void Logger::setLogFilter(QString pattern){
    if(m_logfilter){
        delete m_logfilter;
    }
    m_logfilter = new QRegExp(pattern, Qt::CaseInsensitive, QRegExp::WildcardUnix);
}

void Logger::setLogPrefix(QString prefix){
  m_prefix = prefix;
}
