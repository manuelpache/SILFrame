#ifndef GROUPCOMMUNICATIONRECEIVER_H
#define GROUPCOMMUNICATIONRECEIVER_H

#include "middleware.h"

#include <QString>
#include <QStringList>
#include <QByteArray>
#include <QTcpSocket>
#include <QRegExp>
#include <QDateTime>
#include <QList>
#include <QDataStream>

class GroupCommunicationReceiver: public Middleware {
    Q_OBJECT

public:
    GroupCommunicationReceiver(QTcpSocket *socket, QString peerid, int timeout);
    virtual ~GroupCommunicationReceiver();

    void run();

protected:
    bool isValidHeader(const QStringList *header);
    bool isValidConnection(const QTcpSocket *socket);
    void closeConnection(QTcpSocket* socket);
    bool readIncomingMessage(QTcpSocket *socket, QStringList *msg);
    QByteArray readIncomingData(QTcpSocket *socket);

private:
    QTcpSocket *m_socket;
    QString m_peerid;
    int m_timeout;
};

#endif // GROUPCOMMUNICATIONRECEIVER_H
