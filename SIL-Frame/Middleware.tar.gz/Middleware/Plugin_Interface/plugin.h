#ifndef PLUGIN_H
#define PLUGIN_H

#include "sil_constants.h"

#include <QObject>
#include <QString>
#include <QDateTime>
#include <QMap>
#include <QPair>
#include <QSemaphore>
#include <QUuid>
#include <QString>
#include <QStringList>


class Plugin: public QObject{
    Q_OBJECT

signals:
    /*!
     * \brief Signal emitted when a plug-in executes a logging command for debug
     * \param sender of the log message
     * \param message to be logged
     */
    void loggingDebug(QString sender, QString message);
    /*!
     * \brief Signal emitted when a plug-in executes a logging command for warning
     * \param sender of the log message
     * \param message to be logged
     */
    void loggingWarning(QString sender, QString message);
    /*!
     * \brief Signal emitted when a plug-in executes a logging command for error
     * \param sender of the log message
     * \param message to be logged
     */
    void loggingError(QString sender, QString message);
    /*!
     * \brief Signal emitted to send a message
     * \param receiverpeer id of the receiving peer
     * \param receiverplugin id of the receiving plug-in
     * \param senderpeer id of the peer the message was send from
     * \param senderplugin id of the plug-in that send the message
     * \param timestamp when the message was send
     * \param id identify of the message
     * \param expectingReply
     * \param message contains the actual message
     */
    void sendMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message);

public:
    Plugin(QObject *parent = 0);
    virtual ~Plugin();

    bool setupPlugin(system_mode_t mode);
    bool activatePlugin();
    bool stopPlugin();
    bool shutdownPlugin();
    pluginstatus_t getPluginStatus();
    const QString getQtVersion();
    const QString getPeerID();

    virtual const QString getPluginVersion() = 0;
    virtual const QString getId() = 0;
    virtual const QString getDescription() = 0;
    virtual bool hasGUI();
    virtual bool shouldAutostart();
    virtual const QStringList dependentPlugins();
    virtual QWidget* getWidget(const int width, const int height, QWidget *parent);

public slots:
    virtual void mainloop();

    /*!
     * \brief Provides the incoming point for messages
     * \param receiverpeer id of the receiving peer
     * \param receiverplugin id of the receiving plug-in
     * \param senderpeer id of the peer the message was send from
     * \param senderplugin id of the plug-in that send the message
     * \param timestamp when the message was send
     * \param id identify of the message
     * \param expectingReply indicates if the message required a response
     * \param message contains the actual message
     */
    void receiveMessage(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectingReply, const QString message);

    /*!
     * \brief Shorthand for emitting a log message for debug
     * \param sender of the log message
     * \param message to be logged
     */
    void logDebug(QString message);
    /*!
     * \brief Shorthand for emitting a log message for warning
     * \param sender of the log message
     * \param message to be logged
     */
    void logWarning(QString message);
    /*!
     * \brief Shorthand for emitting a log message for error
     * \param sender of the log message
     * \param message to be logged
     */
    void logError(QString message);

protected:
    virtual bool setup();
    virtual void stop();
    virtual void shutdown();

    /*!
     * \brief send
     * \param receiverpeer id of the receiving peer
     * \param receiverplugin id of the receiving plug-in
     * \param senderpeer id of the peer the message was send from
     * \param senderplugin id of the plug-in that send the message
     * \param id identify of the message
     * \param message contains the actual message
     */
    void send(const QString receiverpeer, const QString receiverplugin, const QString id, const QString message, bool relpyrequest = false);
    /*!
     * \brief syncSend
     * \param receiverpeer id of the receiving peer
     * \param receiverplugin id of the receiving plug-in
     * \param senderpeer id of the peer the message was send from
     * \param senderplugin id of the plug-in that send the message
     * \param message contains the actual message
     * \return response
     */
    QString syncSend(const QString receiverpeer, const QString receiverplugin, const QString message);

    /*!
     * \brief subscribe
     * \param topic
     */
    void subscribe(QString topic, QString peer = ADDR_PEER_LOCAL);
    /*!
     * \brief undubscribe
     * \param topic
     */
    void unsubscribe(QString topic, QString peer = ADDR_PEER_LOCAL);
    /*!
     * \brief announce
     * \param topic
     * \param id
     * \param message
     */
    void announce(QString topic, QString message, QString peer = ADDR_PEER_LOCAL);

    /*!
     * \brief getConfiguration
     * \param key
     * \param sender
     * \return
     */
    QString getConfiguration(QString key);
    QString getGeneralConfiguration(QString key, QString authentication);

    /*!
     * \brief getMode
     * \return
     */
    system_mode_t getMode();

    /*!
     * \brief Processes an incoming message on individal basis
     * \param receiverpeer id of the receiving peer
     * \param receiverplugin id of the receiving plug-in
     * \param senderpeer id of the peer the message was send from
     * \param senderplugin id of the plug-in that send the message
     * \param timestamp when the message was send
     * \param id identify of the message
     * \param expectingReply indicates if the message required a response
     * \param message contains the actual message
     */
    virtual void processMessage(QString receiverpeer,QString receiverplugin, QString senderpeer, QString senderplugin, QDateTime timestamp, QString id, bool expectingReply, QString message) = 0;

    /*!
     * \brief message2str
     * \param receiverpeer id of the receiving peer
     * \param receiverplugin id of the receiving plug-in
     * \param senderpeer id of the peer the message was send from
     * \param senderplugin id of the plug-in that send the message
     * \param timestamp when the message was send
     * \param id identify of the message
     * \param expectingReply indicates if the message required a response
     * \param message contains the actual message
     * \return a single QString describing the message
     */
    QString message2str(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectingReply, const QString message);

private:
    QMap<QString, QPair<QSemaphore*, QString> > *m_currentSynchronousMessages; /*!< list of open messages for with a reply is required */
    QSemaphore *m_plugin_ctrl_lock;
    system_mode_t m_mode;
    pluginstatus_t m_status;
};

Q_DECLARE_INTERFACE(Plugin, "org.sil.ApplicationPlugin")

#endif // PLUGIN_H
