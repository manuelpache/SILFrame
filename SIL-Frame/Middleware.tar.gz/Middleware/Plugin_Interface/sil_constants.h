#ifndef SIL_CONSTANTS_H
#define SIL_CONSTANTS_H

#include <QString>
#include <QStringList>


const static QString SIL_VERION_ID = QString(QT_VERSION_STR) + ";SIL-0.1-ALPHA";

/*!
 * \brief All basic configuration entries of the SIL middleware
 */
const static QStringList CONFIG_ENTRIES = (QStringList() << "configfile" <<  "logfilter" << "iface" << "port" << "peerid" << "mode" << "peers" << "ui" << "uiwidth" << "uiheight" << "defaultplugins" << "guidefaultplugin" << "pluginpath" << "pluginrestrictions");

/*!
 * \brief All required basic configuration entries of the SIL middleware to be initiated
 */
const static QStringList REQUIRED_CONFIG_ENTRIES = (QStringList() << "iface" << "peerid"<< "pluginpath" << "port" << "mode" << "ui" << "uiwidth" << "uiheight");

/*!
 * \brief Default values for required basic configuration entries
 */
const static QStringList REQUIRED_CONFIG_ENTRIES_DEFAULTS = (QStringList() << "eth0" << "PeerOne"<< "./" << "4444" << "simulated" << "true" << "1024" << "768");


//SIL general available topics
const static QString TOPIC_PERCEPTION = "PERCEPTION";

//SIL Middleware commands
const static QString SIL_CMD_SHUTDOWN = "shutdown";

//SIL Middleware Component Identifiers
const static QString SIL_LOCAL = "LocalCommunicationManager";
const static QString SIL_GROUP_OUT = "GroupCommunicationSender"; //
const static QString SIL_GROUP_IN = "GroupCommunicationReceiver";
const static QString SIL_GROUP_SERVER = "GroupCommunicationServer";
const static QString SIL_CONFIG = "Configuration"; //
const static QString SIL_GUI = "GUI"; //
const static QString SIL_PLUGINS = "PluginManager";
const static QString SIL_PEERS = "PeerManager";
const static QString SIL_MIDDLEWARE = "Middleware";

//Addresses used in the SIL middleware
const static QString ADDR_PEER_LOCAL = "local";
const static QString ADDR_MIDDLEWARE = SIL_MIDDLEWARE;
const static QString ADDR_LOCAL = ADDR_MIDDLEWARE + "." + SIL_LOCAL;
const static QString ADDR_GROUP_OUT = ADDR_MIDDLEWARE + "." + SIL_GROUP_OUT;
const static QString ADDR_GROUP_IN = ADDR_MIDDLEWARE + "." + SIL_GROUP_IN;
const static QString ADDR_CONFIGURATION = ADDR_MIDDLEWARE + "." + SIL_CONFIG;
const static QString ADDR_PEERMANAGER = ADDR_MIDDLEWARE + "." + SIL_PEERS;
const static QString ADDR_PLUGINMANAGER = ADDR_MIDDLEWARE + "." + SIL_PLUGINS;
const static QString ADDR_GUI = ADDR_MIDDLEWARE + "." + SIL_GUI;
const static QString ADDR_SUBSCRIBE = ADDR_MIDDLEWARE + "." + "subscribe";
const static QString ADDR_UNSUBSCRIBE = ADDR_MIDDLEWARE + "." + "unsubscribe";
const static QString ADDR_ANNOUNCEMENT = ADDR_MIDDLEWARE + "." + "announce";

//Configuration identifier
const static QString CONF_BASE_PEERID = "peerid";
const static QString CONF_BASE_IP = "ip";
const static QString CONF_BASE_IFACE = "iface";
const static QString CONF_BASE_PORT = "port";
const static QString CONF_BASE_LOGFILTER = "logfilter";
const static QString CONF_BASE_MODE = "mode";
const static QString CONF_BASE_PEERS = "peers";
const static QString CONF_BASE_PLUGIN_PATH = "pluginpath";
const static QString CONF_UI_USED = "ui";
const static QString CONF_UI_WIDTH = "uiwidth";
const static QString CONF_UI_HEIGHT = "uiheight";
const static QString CONF_UI_DEFAULT = "guidefaultplugin";
const static QString CONF_PLUGIN_RESTRICTIONS = "pluginrestrictions";

//Identifier Strings used in program
const static QString BASE_TRUE = "true";
const static QString BASE_FALSE = "false";
const static QString BASE_MODE_NORMAL = "normal";
const static QString BASE_MODE_SIMULATION = "simulation";
const static QString NETWORK_IPV4 = ".+:\\d+\\.\\d+\\.\\d+\\.\\d+:\\d+";
//const static QString NETWORK_IPV6 = ".+:\\d+\\.\\d+\\.\\d+\\.\\d+:\\d+";

const static QString NAME_PEERSTORAGE = "Peers";
const static QString PLUGIN_NAME_RESTDATASTORE = "RESTDataStore";

const static QString UI_TITLE = "Spatial Interaction Laboratory (SIL)";

const static QString RESOURCE_LOGO_SVG = ":/svg/logo.svg";
const static int RESOURCE_LOGO_SVG_WIDTH = 300;
const static int RESOURCE_LOGO_SVG_HEIGHT = 91;

const static int TIMEOUT = 3000;


/*!
 * \enum Enumeration of possible modes the SIL peer and plug-in can run in
 */
enum system_mode_t {
  NORMAL = 0, SIMULATED = 1
};

/*!
 * \enum  Enumeration of all status a plug-in can have
 */
enum pluginstatus_t {
  AVAILABLE = 0, INITIALIZING = 1, INITIALIZED = 2, DEACTIVATED = 3, ACTIVE = 4, STOPPED = 5
};

#endif // SIL_CONSTANTS_H
