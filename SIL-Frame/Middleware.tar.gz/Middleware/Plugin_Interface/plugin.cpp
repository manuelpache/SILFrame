#include "plugin.h"

Plugin::Plugin(QObject *parent):
    QObject(parent), m_currentSynchronousMessages(new QMap<QString, QPair<QSemaphore*, QString> >),
    m_plugin_ctrl_lock(new QSemaphore(1)), m_status(AVAILABLE){
}

Plugin::~Plugin(){
    if(m_currentSynchronousMessages)
        delete m_currentSynchronousMessages;
    if(m_plugin_ctrl_lock)
        delete m_plugin_ctrl_lock;
}

const QString Plugin::getQtVersion(){
    return QString(QT_VERSION_STR);
}

const QString Plugin::getPeerID(){
    return getGeneralConfiguration(CONF_BASE_PEERID, "");
}

bool Plugin::setupPlugin(system_mode_t mode){
    bool success = false;
    m_plugin_ctrl_lock->acquire();
    if(m_status == AVAILABLE){
#ifdef QT_DEBUG
        logDebug("Trying to setup plugin");
#endif
        m_mode = mode;
        m_status = INITIALIZING;
        m_plugin_ctrl_lock->release();
        bool flag = setup();
        m_plugin_ctrl_lock->acquire();
        if(flag){
            m_status = INITIALIZED;
            success = true;
        }else{
            m_status = DEACTIVATED;
        }
    }
    m_plugin_ctrl_lock->release();
    return success;
}

bool Plugin::activatePlugin(){
    bool success = false;
    m_plugin_ctrl_lock->acquire();
    if(m_status == INITIALIZED || m_status == STOPPED){
#ifdef QT_DEBUG
        logDebug("Trying to start plugin");
#endif
        m_status = ACTIVE;
        success = true;
    }
    m_plugin_ctrl_lock->release();
    return success;
}

bool Plugin::stopPlugin(){
    bool success = false;
    m_plugin_ctrl_lock->acquire();
    if(m_status == ACTIVE){
#ifdef QT_DEBUG
    logDebug("Trying to stop plugin");
#endif
        try{
            this->stop();
            m_status = STOPPED;
            success = true;
        }catch(...){
            success = false;
            logError("Failed to stop plug-in");
        }
    }
    m_plugin_ctrl_lock->release();
    return success;
}

bool Plugin::shutdownPlugin(){
    bool success = false;
    if(m_status == ACTIVE){
        stopPlugin();
    }
    m_plugin_ctrl_lock->acquire();
    if(m_status == INITIALIZED || m_status == STOPPED){
#ifdef QT_DEBUG
        logDebug("Trying to shutdown plugin");
#endif
        try{
            this->shutdown();
            m_status = AVAILABLE;
            success = true;
        }catch(...){
            success = false;
            logError("Failed to shutdown plug-in");
        }
    }
    m_plugin_ctrl_lock->release();
    return success;
}

pluginstatus_t Plugin::getPluginStatus(){
    pluginstatus_t status;
    m_plugin_ctrl_lock->acquire();
    status = m_status;
    m_plugin_ctrl_lock->release();
    return status;
}

void Plugin::receiveMessage(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectingReply, const QString message){
#ifdef QT_DEBUG
    logDebug("Incoming => " + message2str(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message));
#endif

    if(!m_currentSynchronousMessages->isEmpty() && m_currentSynchronousMessages->contains(id)){
        //handle synchronous messages
        QPair<QSemaphore*, QString> request = m_currentSynchronousMessages->value(id);
        m_currentSynchronousMessages->remove(id);
        request.second = message;
        m_currentSynchronousMessages->insert(id, request);
        request.first->release();
    }else{
        processMessage(receiverpeer, receiverplugin, senderpeer, senderplugin, timestamp, id, expectingReply, message);
    }
}

void Plugin::send(const QString receiverpeer, const QString receiverplugin, const QString id, const QString message, bool relpyrequest){
    emit sendMessage(receiverpeer, receiverplugin, ADDR_PEER_LOCAL, getId(), QDateTime::currentDateTime(), id, relpyrequest, message);
}

QString Plugin::syncSend(const QString receiverpeer, const QString receiverplugin, const QString message){
    QString uuid = QUuid::createUuid().toString();
    QSemaphore *locallock = new QSemaphore();
    m_currentSynchronousMessages->insert(uuid, qMakePair(locallock, QString()));
    emit sendMessage(receiverpeer, receiverplugin, ADDR_PEER_LOCAL, getId(), QDateTime::currentDateTime(), uuid, true, message);
    locallock->acquire();
    QPair<QSemaphore*, QString> reply = m_currentSynchronousMessages->value(uuid);
    delete locallock;
    return reply.second;
}

void Plugin::subscribe(QString topic, QString peer){
    send(peer, ADDR_SUBSCRIBE, "subscribing", topic);
}

void Plugin::unsubscribe(QString topic, QString peer){
    send(peer, ADDR_SUBSCRIBE, "unsubscribing", topic);
}

void Plugin::announce(QString topic,QString message, QString peer){
    send(peer, ADDR_ANNOUNCEMENT, topic, message);
}

QString Plugin::getConfiguration(QString key){
    return syncSend(ADDR_PEER_LOCAL, ADDR_CONFIGURATION, "get;" + getId() +"/" + key);
}

QString Plugin::getGeneralConfiguration(QString key, QString authentication){
    return syncSend(ADDR_PEER_LOCAL, ADDR_CONFIGURATION, "get;" + key);
}



system_mode_t Plugin::getMode(){
    return m_mode;
}

QString Plugin::message2str(const QString receiverpeer, const QString receiverplugin, const QString senderpeer, const QString senderplugin, const QDateTime timestamp, const QString id, const bool expectingReply, const QString message){
    return ("At " + timestamp.toString(Qt::ISODate) + " received message to: " + receiverpeer + ";" + receiverplugin + " from: " + senderpeer + ";" + senderplugin + " with id: > " + id + " < and message: > " + message + " < -> reply requested: " + (expectingReply? "true" : "false"));
}


void Plugin::logDebug(QString message){
    emit loggingDebug(getId(), message);
}

void Plugin::logWarning(QString message){
    emit loggingWarning(getId(), message);
}

void Plugin::logError(QString message){
    emit loggingError(getId(), message);
}

bool Plugin::hasGUI(){
    return false;
}

bool Plugin::shouldAutostart(){
    return false;
}

const QStringList Plugin::dependentPlugins(){
    return QStringList();
}

QWidget* Plugin::getWidget(const int width, const int height, QWidget *parent){
    return 0;
}

bool Plugin::setup(){
    return true;
}

void Plugin::mainloop(){}

void Plugin::stop(){}

void Plugin::shutdown(){}
